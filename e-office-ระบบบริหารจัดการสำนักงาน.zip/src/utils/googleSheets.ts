import { GeneralRecord, GoogleSheetConfig } from '../types';
import { addSyncLog } from './storage';

export const GOOGLE_APPS_SCRIPT_TEMPLATE = (sheetId: string) => `/**
 * Google Apps Script สำหรับเชื่อมโยง E-OFFICE กับ Google Sheet
 * Spreadsheet ID: ${sheetId}
 */

function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.tryLock(10000);
  
  try {
    var sheetId = "${sheetId}";
    var ss = SpreadsheetApp.openById(sheetId);
    var data = JSON.parse(e.postData.contents);
    
    // 1. บันทึกข้อมูลแยกตามแท็บประเภท
    var action = data.action || 'sync_records';
    var records = data.records || [];
    
    if (action === 'test_connection') {
      return ContentService.createTextOutput(JSON.stringify({
        status: 'success',
        message: 'เชื่อมต่อกับ Google Sheet สำเร็จ!',
        sheetName: ss.getName(),
        updatedAt: new Date().toISOString()
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // ประมวลผลรายการ records
    records.forEach(function(rec) {
      var targetSheetName = getSheetNameForType(rec.type);
      var sheet = ss.getSheetByName(targetSheetName);
      if (!sheet) {
        sheet = ss.insertSheet(targetSheetName);
        initSheetHeaders(sheet, rec.type);
      }
      
      // เพิ่มแถวข้อมูลใหม่
      var row = formatRecordRow(rec);
      sheet.appendRow(row);
    });
    
    // อัปเดตแท็บ Dashboard Summary
    updateSummarySheet(ss, records);
    
    return ContentService.createTextOutput(JSON.stringify({
      status: 'success',
      syncedCount: records.length,
      timestamp: new Date().toISOString()
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: 'error',
      message: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}

function getSheetNameForType(type) {
  switch (type) {
    case 'document': return 'เอกสาร_Documents';
    case 'income': return 'รายรับ_Income';
    case 'expense': return 'รายจ่าย_Expense';
    case 'loan': return 'สินเชื่อ_Loans';
    case 'withdrawal': return 'เบิกเงิน_Withdrawals';
    default: return 'ข้อมูลทั่วไป_General';
  }
}

function initSheetHeaders(sheet, type) {
  var headers = ['รหัสรายการ', 'วันที่', 'หัวข้อ/รายการ', 'หมวดหมู่', 'สถานะ', 'ผู้บันทึก', 'เวลาบันทึก'];
  if (type === 'income' || type === 'expense') {
    headers.push('จำนวนเงิน (บาท)', 'วิธีชำระ', 'เลขอ้างอิง/ใบเสร็จ');
  } else if (type === 'document') {
    headers.push('เลขที่หนังสือ', 'ประเภทหนังสือ', 'จาก/ผู้ส่ง', 'ถึง/ผู้รับ');
  } else if (type === 'loan') {
    headers.push('วงเงินกู้ (บาท)', 'ผู้กู้', 'ดอกเบี้ย (%)', 'ค่างวด/เดือน', 'วันที่ต้องชำระ');
  } else if (type === 'withdrawal') {
    headers.push('จำนวนเงินเบิก (บาท)', 'ผู้ขอเบิก', 'ผู้อนุมัติ', 'วันที่อนุมัติ');
  }
  sheet.appendRow(headers);
  sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#E2E8F0');
}

function formatRecordRow(rec) {
  var base = [
    rec.recordNumber || rec.id,
    rec.date || '',
    rec.title || '',
    rec.category || '',
    rec.status || '',
    rec.createdByName || '',
    new Date().toLocaleString('th-TH')
  ];
  
  if (rec.type === 'income' || rec.type === 'expense') {
    base.push(rec.amount || 0, rec.paymentMethod || '', rec.referenceNumber || '');
  } else if (rec.type === 'document') {
    base.push(rec.documentNumber || '', rec.documentType || '', rec.sender || '', rec.receiver || '');
  } else if (rec.type === 'loan') {
    base.push(rec.amount || 0, rec.borrowerName || '', rec.interestRate || 0, rec.monthlyInstallment || 0, rec.dueDate || '');
  } else if (rec.type === 'withdrawal') {
    base.push(rec.amount || 0, rec.applicantName || '', rec.approverName || '', rec.approvalDate || '');
  }
  return base;
}

function updateSummarySheet(ss, records) {
  var sheet = ss.getSheetByName('สรุปภาพรวม_Dashboard');
  if (!sheet) {
    sheet = ss.insertSheet('สรุปภาพรวม_Dashboard', 0);
    sheet.appendRow(['หัวข้อรายงาน', 'ค่าสรุป', 'ปรับปรุงล่าสุด']);
    sheet.getRange(1, 1, 1, 3).setFontWeight('bold').setBackground('#CBD5E1');
  }
  sheet.appendRow(['ซิงค์ข้อมูลชุดใหม่', records.length + ' รายการ', new Date().toLocaleString('th-TH')]);
}
`;

/**
 * Trigger sync to Google Sheet via Webhook
 */
export async function syncRecordsToGoogleSheet(
  records: GeneralRecord[],
  config: GoogleSheetConfig
): Promise<{ success: boolean; message: string; syncedCount: number }> {
  if (!config.webhookUrl) {
    // If webhook is not configured yet, simulate local sync queue & save
    addSyncLog({
      action: 'ซิงค์ข้อมูล Google Sheet (Local Cache/Ready)',
      status: 'success',
      details: `เตรียมข้อมูล ${records.length} รายการสำหรับ Google Sheet: ${config.sheetId} (กรุณากรอก Webhook URL เพื่อยิงตรงแบบ Real-time)`,
      itemCount: records.length,
    });
    return {
      success: true,
      message: `บันทึกข้อมูลเตรียมส่งเข้า Google Sheet (${records.length} รายการ) สำเร็จ`,
      syncedCount: records.length,
    };
  }

  try {
    const payload = {
      action: 'sync_records',
      sheetId: config.sheetId,
      timestamp: new Date().toISOString(),
      records: records.map(r => ({
        ...r,
        attachments: r.attachments.map(a => ({ id: a.id, name: a.name, size: a.size, type: a.type })) // exclude heavy base64
      }))
    };

    const response = await fetch(config.webhookUrl, {
      method: 'POST',
      mode: 'no-cors', // Google Apps Script redirects with 302
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    addSyncLog({
      action: 'ซิงค์ข้อมูล Google Sheet สำเร็จ',
      status: 'success',
      details: `ส่งข้อมูล ${records.length} รายการไปยัง Google Sheet: ${config.sheetId}`,
      itemCount: records.length,
    });

    return {
      success: true,
      message: `ซิงค์ข้อมูล ${records.length} รายการลง Google Sheet สำเร็จ!`,
      syncedCount: records.length,
    };
  } catch (err: any) {
    console.error('Google Sheet Sync Error:', err);
    addSyncLog({
      action: 'ซิงค์ข้อมูล Google Sheet ล้มเหลว',
      status: 'failed',
      details: err.message || 'ไม่สามารถเชื่อมต่อ Webhook ได้',
      itemCount: records.length,
    });
    return {
      success: false,
      message: `เกิดข้อผิดพลาดในการซิงค์: ${err.message || 'Network error'}`,
      syncedCount: 0,
    };
  }
}

/**
 * Test Webhook Connection
 */
export async function testSheetWebhook(webhookUrl: string, sheetId: string): Promise<boolean> {
  if (!webhookUrl) return false;
  try {
    await fetch(webhookUrl, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'test_connection', sheetId }),
    });
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Export records as CSV with UTF-8 BOM for Microsoft Excel & Google Sheets
 */
export function exportRecordsToCSV(records: GeneralRecord[], filename = 'e-office-export.csv') {
  const headers = [
    'รหัสรายการ',
    'ประเภท',
    'วันที่',
    'หัวข้อ',
    'หมวดหมู่',
    'สถานะ',
    'จำนวนเงิน (บาท)',
    'วิธีชำระ',
    'เลขที่อ้างอิง/หนังสือ',
    'ผู้บันทึก/ผู้ขอ',
    'วันที่ชำระ/กำหนดชำระ',
    'รายละเอียด',
  ];

  const typeLabels: Record<string, string> = {
    document: 'เอกสาร',
    income: 'รายรับ',
    expense: 'รายจ่าย',
    loan: 'สินเชื่อ',
    withdrawal: 'เบิกเงิน',
  };

  const statusLabels: Record<string, string> = {
    completed: 'เสร็จสมบูรณ์',
    pending: 'รอดำเนินการ',
    cancelled: 'ยกเลิก',
    approved: 'อนุมัติแล้ว',
    rejected: 'ไม่อนุมัติ',
  };

  const rows = records.map(r => [
    `"${r.recordNumber || r.id}"`,
    `"${typeLabels[r.type] || r.type}"`,
    `"${r.date}"`,
    `"${(r.title || '').replace(/"/g, '""')}"`,
    `"${r.category || ''}"`,
    `"${statusLabels[r.status] || r.status}"`,
    `"${r.amount != null ? r.amount : ''}"`,
    `"${r.paymentMethod || ''}"`,
    `"${r.documentNumber || r.referenceNumber || ''}"`,
    `"${r.borrowerName || r.applicantName || r.createdByName || ''}"`,
    `"${r.dueDate || r.approvalDate || ''}"`,
    `"${(r.description || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Export records as Excel XML (.xls) formatted with table styling
 */
export function exportRecordsToExcel(records: GeneralRecord[], filename = 'e-office-data.xls') {
  const typeLabels: Record<string, string> = {
    document: 'เอกสาร',
    income: 'รายรับ',
    expense: 'รายจ่าย',
    loan: 'สินเชื่อ',
    withdrawal: 'เบิกเงิน',
  };

  const statusLabels: Record<string, string> = {
    completed: 'เสร็จสมบูรณ์',
    pending: 'รอดำเนินการ',
    cancelled: 'ยกเลิก',
    approved: 'อนุมัติแล้ว',
    rejected: 'ไม่อนุมัติ',
  };

  const rowsHtml = records.map((r, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${r.recordNumber || r.id}</td>
      <td>${typeLabels[r.type] || r.type}</td>
      <td>${r.date}</td>
      <td>${r.title}</td>
      <td>${r.category}</td>
      <td style="text-align: right;">${r.amount ? r.amount.toLocaleString() : '-'}</td>
      <td>${statusLabels[r.status] || r.status}</td>
      <td>${r.documentNumber || r.referenceNumber || '-'}</td>
      <td>${r.borrowerName || r.applicantName || r.createdByName}</td>
      <td>${r.dueDate || r.approvalDate || '-'}</td>
    </tr>
  `).join('');

  const htmlTable = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta charset="utf-8" />
      <style>
        table { border-collapse: collapse; width: 100%; font-family: 'Prompt', 'Sarabun', Tahoma, sans-serif; font-size: 13px; }
        th { background-color: #1E3A8A; color: white; border: 1px solid #94A3B8; padding: 8px; text-align: left; }
        td { border: 1px solid #CBD5E1; padding: 6px; }
      </style>
    </head>
    <body>
      <h2>รายงานระบบ E-OFFICE</h2>
      <p>เชื่อมโยง Google Sheet ID: 1n2n7pq9E0pFyyVRgO_vkbobyxfu2h7CD9xPMRrqamZw</p>
      <p>ส่งออกข้อมูลเมื่อ: ${new Date().toLocaleString('th-TH')}</p>
      <table>
        <thead>
          <tr>
            <th>ลำดับ</th>
            <th>รหัสรายการ</th>
            <th>ประเภท</th>
            <th>วันที่</th>
            <th>หัวข้อรายการ</th>
            <th>หมวดหมู่</th>
            <th>จำนวนเงิน (บาท)</th>
            <th>สถานะ</th>
            <th>เลขอ้างอิง/หนังสือ</th>
            <th>ผู้บันทึก/ผู้รับผิดชอบ</th>
            <th>กำหนดชำระ/วันที่</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
    </body>
    </html>
  `;

  const blob = new Blob([htmlTable], { type: 'application/vnd.ms-excel;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
