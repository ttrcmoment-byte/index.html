import { AppUser, GeneralRecord, GoogleSheetConfig } from '../types';
import { INITIAL_USERS, INITIAL_RECORDS, INITIAL_SHEET_CONFIG } from '../mockData';

const STORAGE_KEYS = {
  CURRENT_USER: 'eoffice_current_user',
  USERS: 'eoffice_users_list',
  RECORDS: 'eoffice_records_list',
  SHEET_CONFIG: 'eoffice_sheet_config',
  SYNC_LOGS: 'eoffice_sync_logs',
};

export interface SyncLogItem {
  id: string;
  timestamp: string;
  action: string;
  status: 'success' | 'failed';
  details: string;
  itemCount: number;
}

export function getCurrentUser(): AppUser | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (!raw) {
      // Default to initial admin on first run for instant smooth preview experience
      const admin = INITIAL_USERS[0];
      setCurrentUser(admin);
      return admin;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to get current user from storage', e);
    return INITIAL_USERS[0];
  }
}

export function setCurrentUser(user: AppUser | null): void {
  try {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  } catch (e) {
    console.error('Failed to set current user', e);
  }
}

export function getUsers(): AppUser[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
    return JSON.parse(raw);
  } catch (e) {
    return INITIAL_USERS;
  }
}

export function saveUsers(users: AppUser[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  } catch (e) {
    console.error('Failed to save users', e);
  }
}

export function getRecords(): GeneralRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RECORDS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(INITIAL_RECORDS));
      return INITIAL_RECORDS;
    }
    const parsed: GeneralRecord[] = JSON.parse(raw);
    const normalized = parsed.map(r => {
      if (!r.createdByUserId) {
        const init = INITIAL_RECORDS.find(i => i.id === r.id);
        return {
          ...r,
          createdByUserId: init?.createdByUserId || 'user-admin-01',
          createdByName: init?.createdByName || 'ผู้ดูแลระบบ (Admin E-Office)',
        };
      }
      return r;
    });
    return normalized;
  } catch (e) {
    return INITIAL_RECORDS;
  }
}

export function saveRecords(records: GeneralRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(records));
  } catch (e) {
    console.error('Failed to save records', e);
  }
}

export function getSheetConfig(): GoogleSheetConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SHEET_CONFIG);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SHEET_CONFIG, JSON.stringify(INITIAL_SHEET_CONFIG));
      return INITIAL_SHEET_CONFIG;
    }
    return JSON.parse(raw);
  } catch (e) {
    return INITIAL_SHEET_CONFIG;
  }
}

export function saveSheetConfig(config: GoogleSheetConfig): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SHEET_CONFIG, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save sheet config', e);
  }
}

export function getSyncLogs(): SyncLogItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SYNC_LOGS);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function addSyncLog(log: Omit<SyncLogItem, 'id' | 'timestamp'>): void {
  try {
    const current = getSyncLogs();
    const newLog: SyncLogItem = {
      ...log,
      id: 'log-' + Date.now(),
      timestamp: new Date().toISOString(),
    };
    const updated = [newLog, ...current].slice(0, 50); // Keep last 50 logs
    localStorage.setItem(STORAGE_KEYS.SYNC_LOGS, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to add sync log', e);
  }
}

export function resetAllToDefault(): void {
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
  localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(INITIAL_RECORDS));
  localStorage.setItem(STORAGE_KEYS.SHEET_CONFIG, JSON.stringify(INITIAL_SHEET_CONFIG));
  localStorage.removeItem(STORAGE_KEYS.SYNC_LOGS);
  setCurrentUser(INITIAL_USERS[0]);
}
