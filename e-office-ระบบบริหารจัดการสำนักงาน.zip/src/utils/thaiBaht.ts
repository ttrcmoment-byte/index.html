/**
 * Utility to convert numeric currency values into Thai Baht text
 * e.g., 150000.50 -> "หนึ่งแสนห้าหมื่นบาทห้าสิบสตางค์"
 * e.g., 10000 -> "หนึ่งหมื่นบาทถ้วน"
 */
export function thaiBahtText(num: number | undefined | null): string {
  if (num === undefined || num === null || isNaN(num)) return '-';
  if (num === 0) return 'ศูนย์บาทถ้วน';

  const numbers = ['ศูนย์', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า'];
  const units = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน'];

  const isNegative = num < 0;
  const absNum = Math.abs(num);

  const [bahtStr, satangStrRaw] = absNum.toFixed(2).split('.');
  const satangNum = parseInt(satangStrRaw || '0', 10);

  function convertGroup(nStr: string): string {
    let result = '';
    const len = nStr.length;
    for (let i = 0; i < len; i++) {
      const digit = parseInt(nStr[i], 10);
      const pos = len - i - 1;

      if (digit === 0) continue;

      if (pos === 1 && digit === 1) {
        result += 'สิบ';
      } else if (pos === 1 && digit === 2) {
        result += 'ยี่สิบ';
      } else if (pos === 0 && digit === 1 && len > 1 && parseInt(nStr[len - 2], 10) !== 0) {
        result += 'เอ็ด';
      } else {
        result += numbers[digit] + units[pos];
      }
    }
    return result;
  }

  function convertBaht(bStr: string): string {
    if (bStr === '0' || bStr === '') return '';
    let result = '';
    // Handle numbers larger than millions
    let remaining = bStr;
    let millionCount = 0;

    while (remaining.length > 6) {
      const chunk = remaining.slice(-6);
      remaining = remaining.slice(0, -6);
      const chunkText = convertGroup(chunk);
      if (chunkText) {
        result = chunkText + (millionCount > 0 ? 'ล้าน'.repeat(millionCount) : '') + result;
      }
      millionCount++;
    }

    if (remaining.length > 0) {
      const chunkText = convertGroup(remaining);
      if (chunkText) {
        result = chunkText + (millionCount > 0 ? 'ล้าน'.repeat(millionCount) : '') + result;
      }
    }

    return result;
  }

  let text = '';
  const bahtText = convertBaht(bahtStr);

  if (bahtText) {
    text += bahtText + 'บาท';
  } else if (satangNum > 0) {
    // No baht part
  } else {
    text += 'ศูนย์บาท';
  }

  if (satangNum === 0) {
    text += 'ถ้วน';
  } else {
    const sStr = satangStrRaw;
    let satangText = '';
    const d0 = parseInt(sStr[0], 10);
    const d1 = parseInt(sStr[1], 10);

    if (d0 === 1) satangText += 'สิบ';
    else if (d0 === 2) satangText += 'ยี่สิบ';
    else if (d0 > 2) satangText += numbers[d0] + 'สิบ';

    if (d1 === 1 && d0 > 0) satangText += 'เอ็ด';
    else if (d1 > 0) satangText += numbers[d1];

    text += satangText + 'สตางค์';
  }

  return (isNegative ? 'ลบ' : '') + text;
}
