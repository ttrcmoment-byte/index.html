import React, { useState, useEffect } from 'react';
import { AppUser, GeneralRecord, GoogleSheetConfig, ActiveTab, FileAttachment } from './types';
import { 
  getCurrentUser, 
  setCurrentUser, 
  getUsers, 
  saveUsers, 
  getRecords, 
  saveRecords, 
  getSheetConfig, 
  saveSheetConfig 
} from './utils/storage';
import { syncRecordsToGoogleSheet } from './utils/googleSheets';

import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { DashboardView } from './components/DashboardView';
import { AdminGeneralView } from './components/AdminGeneralView';
import { PersonnelView } from './components/PersonnelView';
import { UserManagementView } from './components/UserManagementView';
import { GoogleSheetSyncModal } from './components/GoogleSheetSyncModal';
import { FilePreviewModal } from './components/FilePreviewModal';
import { PrintTemplate } from './components/PrintTemplate';
import { LoginModal } from './components/LoginModal';

export default function App() {
  // Session and State
  const [currentUserState, setCurrentUserState] = useState<AppUser | null>(getCurrentUser());
  const [users, setUsers] = useState<AppUser[]>(getUsers());
  const [records, setRecords] = useState<GeneralRecord[]>(getRecords());
  const [sheetConfig, setSheetConfig] = useState<GoogleSheetConfig>(getSheetConfig());
  
  // Navigation
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Modals
  const [isSheetModalOpen, setIsSheetModalOpen] = useState(false);
  const [isAddRecordModalOpen, setIsAddRecordModalOpen] = useState(false);
  const [previewAttachment, setPreviewAttachment] = useState<FileAttachment | null>(null);
  const [printRecord, setPrintRecord] = useState<GeneralRecord | null>(null);
  
  // Status and Toast
  const [isSyncing, setIsSyncing] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Sync to Google Sheet handler
  const handleTriggerSync = async () => {
    setIsSyncing(true);
    try {
      const result = await syncRecordsToGoogleSheet(records, sheetConfig);
      if (result.success) {
        const updatedConfig: GoogleSheetConfig = {
          ...sheetConfig,
          lastSyncedAt: new Date().toISOString(),
          syncStatus: 'success',
          totalSyncedCount: result.syncedCount,
        };
        setSheetConfig(updatedConfig);
        saveSheetConfig(updatedConfig);

        // Update records synced state
        const updatedRecords = records.map(r => ({ ...r, syncedToGoogleSheet: true, syncedAt: new Date().toISOString() }));
        setRecords(updatedRecords);
        saveRecords(updatedRecords);

        showToast(result.message, 'success');
      } else {
        showToast(result.message, 'error');
      }
    } catch (e: any) {
      showToast('การซิงค์ล้มเหลว: ' + e.message, 'error');
    } finally {
      setIsSyncing(false);
    }
  };

  // Save Record
  const handleSaveRecord = async (record: GeneralRecord) => {
    let updatedRecords: GeneralRecord[];
    const exists = records.some(r => r.id === record.id);
    if (exists) {
      updatedRecords = records.map(r => r.id === record.id ? record : r);
    } else {
      updatedRecords = [record, ...records];
    }

    setRecords(updatedRecords);
    saveRecords(updatedRecords);
    showToast(exists ? 'บันทึกการแก้ไขเรียบร้อย' : 'บันทึกข้อมูลใหม่เรียบร้อย', 'success');

    // Auto-sync if admin and autoSync is enabled
    // Note requirement: "หน้าผู้ไม่ต้องการซิงคืข้อมูล EXpost อย่างเดียว"
    if (currentUserState?.role === 'admin' && sheetConfig.autoSync) {
      try {
        await syncRecordsToGoogleSheet(updatedRecords, sheetConfig);
      } catch (e) {
        console.error('Auto sync failed:', e);
      }
    }
  };

  // Delete Record
  const handleDeleteRecord = (recordId: string) => {
    const updated = records.filter(r => r.id !== recordId);
    setRecords(updated);
    saveRecords(updated);
    showToast('ลบรายการเรียบร้อยแล้ว', 'info');
  };

  // User Management Handlers
  const handleSaveUser = (user: AppUser) => {
    let updatedUsers: AppUser[];
    const exists = users.some(u => u.id === user.id);
    if (exists) {
      updatedUsers = users.map(u => u.id === user.id ? user : u);
    } else {
      updatedUsers = [...users, user];
    }
    setUsers(updatedUsers);
    saveUsers(updatedUsers);
    showToast(exists ? 'อัปเดตข้อมูลผู้ใช้เรียบร้อย' : 'เพิ่มผู้ใช้งานใหม่เรียบร้อย', 'success');
  };

  const handleDeleteUser = (userId: string) => {
    const updated = users.filter(u => u.id !== userId);
    setUsers(updated);
    saveUsers(updated);
    showToast('ลบผู้ใช้งานเรียบร้อยแล้ว', 'info');
  };

  const handleUpdateCurrentUser = (user: AppUser) => {
    setCurrentUserState(user);
    setCurrentUser(user);
  };

  const handleLoginSuccess = (user: AppUser) => {
    setCurrentUserState(user);
    setCurrentUser(user);
    setActiveTab('dashboard');
    showToast(`ยินดีต้อนรับคุณ ${user.fullName} (${user.role.toUpperCase()})`, 'success');
  };

  const handleLogout = () => {
    setCurrentUserState(null);
    setCurrentUser(null);
  };

  // View File modal trigger
  const handleViewFile = (record: GeneralRecord) => {
    if (record.attachments && record.attachments.length > 0) {
      setPreviewAttachment(record.attachments[0]);
    } else {
      showToast('รายการนี้ไม่มีไฟล์แนบ', 'info');
    }
  };

  // Print Record modal trigger
  const handlePrintRecord = (record: GeneralRecord) => {
    setPrintRecord(record);
  };

  // If not logged in, show Login Screen
  if (!currentUserState) {
    return <LoginModal users={users} onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-sky-50/50 to-indigo-50/60 flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className={`px-4 py-3 rounded-2xl shadow-xl border text-sm font-semibold flex items-center space-x-2 ${
            toastMessage.type === 'success' ? 'bg-emerald-800 text-white border-emerald-700' :
            toastMessage.type === 'error' ? 'bg-rose-800 text-white border-rose-700' :
            'bg-slate-800 text-white border-slate-700'
          }`}>
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        currentUser={currentUserState}
        onLogout={handleLogout}
        onOpenSheetModal={() => setIsSheetModalOpen(true)}
        sheetConfig={sheetConfig}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      />

      {/* Main Layout Body - Full screen optimized for PC */}
      <div className="flex-1 flex w-full">
        {/* Left Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          role={currentUserState.role}
          isMobileOpen={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
          onOpenSheetModal={() => setIsSheetModalOpen(true)}
        />

        {/* Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto w-full min-w-0">
          {activeTab === 'dashboard' && (
            <DashboardView
              records={records}
              currentUser={currentUserState}
              sheetConfig={sheetConfig}
              onOpenSheetModal={() => setIsSheetModalOpen(true)}
              onViewFile={handleViewFile}
              onPrintRecord={handlePrintRecord}
              onTriggerSync={handleTriggerSync}
              isSyncing={isSyncing}
            />
          )}

          {activeTab === 'general' && (
            <AdminGeneralView
              records={records}
              currentUser={currentUserState}
              onSaveRecord={handleSaveRecord}
              onDeleteRecord={handleDeleteRecord}
              onViewFile={handleViewFile}
              onPrintRecord={handlePrintRecord}
              isAddModalOpen={isAddRecordModalOpen}
              setIsAddModalOpen={setIsAddRecordModalOpen}
            />
          )}

          {activeTab === 'personnel' && currentUserState.role === 'admin' && (
            <PersonnelView
              users={users}
              onSaveUser={handleSaveUser}
              currentUser={currentUserState}
            />
          )}

          {activeTab === 'users' && (
            <UserManagementView
              users={users}
              currentUser={currentUserState}
              onSaveUser={handleSaveUser}
              onDeleteUser={handleDeleteUser}
              onUpdateCurrentUser={handleUpdateCurrentUser}
              onLogout={handleLogout}
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        role={currentUserState.role}
        onOpenAddModal={() => {
          setActiveTab('general');
          setIsAddRecordModalOpen(true);
        }}
      />

      {/* Google Sheet Sync & Setup Guide Modal */}
      {isSheetModalOpen && (
        <GoogleSheetSyncModal
          config={sheetConfig}
          onSaveConfig={(newCfg) => {
            setSheetConfig(newCfg);
            saveSheetConfig(newCfg);
            showToast('บันทึกการตั้งค่า Google Sheet สำเร็จ', 'success');
          }}
          onTriggerSync={handleTriggerSync}
          onClose={() => setIsSheetModalOpen(false)}
          isSyncing={isSyncing}
        />
      )}

      {/* File Preview Modal */}
      {previewAttachment && (
        <FilePreviewModal
          attachment={previewAttachment}
          onClose={() => setPreviewAttachment(null)}
        />
      )}

      {/* Print Document Modal */}
      {printRecord && (
        <PrintTemplate
          record={printRecord}
          onClose={() => setPrintRecord(null)}
        />
      )}
    </div>
  );
}
