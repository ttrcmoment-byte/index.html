export type UserRole = 'admin' | 'user';

export interface AppUser {
  id: string;
  username: string;
  password: string;
  fullName: string;
  role: UserRole;
  department: string;
  position: string;
  phone: string;
  email: string;
  avatarUrl?: string;
  createdAt: string;
  status: 'active' | 'inactive';
}

export type RecordType = 'document' | 'income' | 'expense' | 'loan' | 'withdrawal';

export interface FileAttachment {
  id: string;
  name: string;
  size: number;
  type: string;
  dataUrl?: string; // base64 data url or preview
  uploadedAt: string;
}

export interface GeneralRecord {
  id: string;
  recordNumber: string; // เช่น DOC-2025-001, REV-001, EXP-001
  type: RecordType;
  title: string;
  description?: string;
  amount?: number;
  category: string;
  date: string; // YYYY-MM-DD
  status: 'completed' | 'pending' | 'cancelled' | 'approved' | 'rejected';
  
  // Specific fields for different types
  // 1. เอกสาร (Document)
  documentNumber?: string;
  documentType?: 'หนังสือเข้า' | 'หนังสือออก' | 'คำสั่ง' | 'บันทึกข้อความ' | 'สัญญา' | 'อื่นๆ';
  sender?: string;
  receiver?: string;

  // 2. รายรับ / รายจ่าย (Income / Expense)
  paymentMethod?: 'เงินสด' | 'โอนผ่านธนาคาร' | 'เช็ค' | 'บัตรเครดิต';
  referenceNumber?: string; // เลขที่ใบเสร็จ / ใบแจ้งหนี้

  // 3. สินเชื่อ (Loan)
  borrowerName?: string;
  installmentCount?: number; // จำนวนงวด
  interestRate?: number; // % ต่อปี
  loanTermMonths?: number;
  dueDate?: string; // วันที่ชำระ
  monthlyInstallment?: number; // ค่างวดต่อเดือน
  totalPaid?: number; // จำนวนที่จ่ายแล้ว

  // 4. เบิกเงิน (Withdrawal)
  applicantName?: string; // ผู้ขอเบิก
  approverName?: string; // ผู้อนุมัติ
  approvalDate?: string;
  approvalNote?: string;

  // Files & Meta
  attachments: FileAttachment[];
  createdByUserId: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
  syncedToGoogleSheet?: boolean;
  syncedAt?: string;
}

export interface GoogleSheetConfig {
  sheetId: string;
  sheetUrl: string;
  webhookUrl: string;
  autoSync: boolean;
  lastSyncedAt?: string;
  syncStatus: 'idle' | 'syncing' | 'success' | 'error';
  errorMessage?: string;
  totalSyncedCount: number;
}

export type ActiveTab = 'dashboard' | 'general' | 'personnel' | 'users' | 'sheet_sync';
