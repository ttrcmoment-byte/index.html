import React from 'react';
import { ActiveTab, UserRole } from '../types';
import { LayoutDashboard, FileText, UserCheck, Users, PlusCircle } from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  role: UserRole;
  onOpenAddModal: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  role,
  onOpenAddModal,
}) => {
  const isAdmin = role === 'admin';

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1 flex items-center justify-around shadow-lg">
      <button
        onClick={() => setActiveTab('dashboard')}
        className={`flex flex-col items-center py-1.5 px-2 rounded-lg transition ${
          activeTab === 'dashboard' ? 'text-blue-600 font-semibold' : 'text-slate-500 hover:text-slate-700'
        }`}
      >
        <LayoutDashboard className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">แดชบอร์ด</span>
      </button>

      <button
        onClick={() => setActiveTab('general')}
        className={`flex flex-col items-center py-1.5 px-2 rounded-lg transition ${
          activeTab === 'general' ? 'text-blue-600 font-semibold' : 'text-slate-500 hover:text-slate-700'
        }`}
      >
        <FileText className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">ธุรการ</span>
      </button>

      {/* Quick Add floating action for mobile */}
      <button
        onClick={onOpenAddModal}
        className="flex flex-col items-center justify-center -mt-5 bg-gradient-to-tr from-blue-600 to-indigo-600 text-white rounded-full w-12 h-12 shadow-lg shadow-blue-600/30 active:scale-95 transition"
        title="บันทึกข้อมูลใหม่"
      >
        <PlusCircle className="w-6 h-6" />
      </button>

      {isAdmin && (
        <button
          onClick={() => setActiveTab('personnel')}
          className={`flex flex-col items-center py-1.5 px-2 rounded-lg transition ${
            activeTab === 'personnel' ? 'text-blue-600 font-semibold' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <UserCheck className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">งานบุคคล</span>
        </button>
      )}

      <button
        onClick={() => setActiveTab('users')}
        className={`flex flex-col items-center py-1.5 px-2 rounded-lg transition ${
          activeTab === 'users' ? 'text-blue-600 font-semibold' : 'text-slate-500 hover:text-slate-700'
        }`}
      >
        <Users className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">{isAdmin ? 'ผู้ใช้งาน' : 'บัญชีฉัน'}</span>
      </button>
    </div>
  );
};
