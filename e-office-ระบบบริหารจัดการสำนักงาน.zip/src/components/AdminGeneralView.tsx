import React, { useState, useMemo } from 'react';
import { GeneralRecord, RecordType, AppUser, FileAttachment } from '../types';
import { 
  FileText, 
  TrendingUp, 
  TrendingDown, 
  Landmark, 
  CreditCard, 
  Plus, 
  Search, 
  Paperclip, 
  Eye, 
  Printer, 
  Edit3, 
  Trash2, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  X, 
  Upload, 
  AlertCircle,
  FileCheck,
  Check,
  Filter
} from 'lucide-react';

interface AdminGeneralViewProps {
  records: GeneralRecord[];
  currentUser: AppUser;
  onSaveRecord: (record: GeneralRecord) => void;
  onDeleteRecord: (recordId: string) => void;
  onViewFile: (record: GeneralRecord) => void;
  onPrintRecord: (record: GeneralRecord) => void;
  onPrintReport?: (payload: { title: string; records: GeneralRecord[]; filterSummary?: string }) => void;
  isAddModalOpen: boolean;
  setIsAddModalOpen: (open: boolean) => void;
}

export const AdminGeneralView: React.FC<AdminGeneralViewProps> = ({
  records,
  currentUser,
  onSaveRecord,
  onDeleteRecord,
  onViewFile,
  onPrintRecord,
  isAddModalOpen,
  setIsAddModalOpen,
  onPrintReport,
}) => {
  const isAdmin = currentUser.role === 'admin';

  // Sub-tabs for ธุรการ
  type SubTab = 'all' | 'document' | 'income' | 'expense' | 'loan' | 'due_date' | 'withdrawal';
  const [activeSubTab, setActiveSubTab] = useState<SubTab>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [selectedAuthorFilter, setSelectedAuthorFilter] = useState<string>('all');

  // Edit / Delete state
  const [editingRecord, setEditingRecord] = useState<GeneralRecord | null>(null);
  const [recordToDelete, setRecordToDelete] = useState<GeneralRecord | null>(null);

  // Extract unique authors for Admin to filter by specific user
  const authorList = useMemo(() => {
    const map = new Map<string, string>();
    records.forEach((r) => {
      const id = r.createdByUserId || 'unknown';
      const name = r.createdByName || 'ไม่ระบุชื่อ';
      if (!map.has(id)) {
        map.set(id, name);
      }
    });
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }));
  }, [records]);

  // Form State for Add / Edit Modal
  const [formType, setFormType] = useState<RecordType>('document');
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formAmount, setFormAmount] = useState<string>('');
  const [formDate, setFormDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [formDescription, setFormDescription] = useState('');
  const [formStatus, setFormStatus] = useState<GeneralRecord['status']>('completed');

  // Specific form states
  const [formDocNumber, setFormDocNumber] = useState('');
  const [formDocType, setFormDocType] = useState<string>('บันทึกข้อความ');
  const [formSender, setFormSender] = useState('');
  const [formReceiver, setFormReceiver] = useState('');
  
  const [formPaymentMethod, setFormPaymentMethod] = useState<any>('โอนผ่านธนาคาร');
  const [formReferenceNumber, setFormReferenceNumber] = useState('');

  const [formBorrowerName, setFormBorrowerName] = useState('');
  const [formInstallmentCount, setFormInstallmentCount] = useState('12');
  const [formLoanTermMonths, setFormLoanTermMonths] = useState('12');
  const [formDueDate, setFormDueDate] = useState('');
  const [formMonthlyInstallment, setFormMonthlyInstallment] = useState('');

  const [formApplicantName, setFormApplicantName] = useState('');

  // Attachments in current modal
  const [attachments, setAttachments] = useState<FileAttachment[]>([]);

  // Filter records based on role and active tab/search
  // Regular user: ONLY their own records
  // Admin: ALL records, with optional filter by specific user
  const filteredRecords = useMemo(() => {
    let list: GeneralRecord[];
    if (isAdmin) {
      if (selectedAuthorFilter === 'all') {
        list = [...records];
      } else {
        list = records.filter(
          (r) => r.createdByUserId === selectedAuthorFilter || r.createdByName === selectedAuthorFilter
        );
      }
    } else {
      list = records.filter(
        (r) =>
          (r.createdByUserId && r.createdByUserId === currentUser.id) ||
          (r.createdByName && r.createdByName === currentUser.fullName)
      );
    }

    // Sub-tab filter
    if (activeSubTab === 'due_date') {
      // "วันที่ชำระ" filters for loans or records with due dates
      list = list.filter((r) => r.type === 'loan' || r.dueDate);
    } else if (activeSubTab !== 'all') {
      list = list.filter((r) => r.type === activeSubTab);
    }

    // Category filter
    if (categoryFilter !== 'all') {
      list = list.filter((r) => r.category === categoryFilter);
    }

    // Search term
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      list = list.filter(
        (r) =>
          r.title.toLowerCase().includes(q) ||
          (r.recordNumber && r.recordNumber.toLowerCase().includes(q)) ||
          (r.category && r.category.toLowerCase().includes(q)) ||
          (r.documentNumber && r.documentNumber.toLowerCase().includes(q)) ||
          (r.borrowerName && r.borrowerName.toLowerCase().includes(q)) ||
          (r.applicantName && r.applicantName.toLowerCase().includes(q)) ||
          (r.sender && r.sender.toLowerCase().includes(q)) ||
          (r.receiver && r.receiver.toLowerCase().includes(q)) ||
          (r.createdByName && r.createdByName.toLowerCase().includes(q))
      );
    }

    return list;
  }, [records, isAdmin, currentUser.id, currentUser.fullName, selectedAuthorFilter, activeSubTab, categoryFilter, searchTerm]);

  // KPIs for the active view
  const viewStats = useMemo(() => {
    const income = filteredRecords.filter((r) => r.type === 'income').reduce((sum, r) => sum + (r.amount || 0), 0);
    const expense = filteredRecords.filter((r) => r.type === 'expense').reduce((sum, r) => sum + (r.amount || 0), 0);
    const loan = filteredRecords.filter((r) => r.type === 'loan').reduce((sum, r) => sum + (r.amount || 0), 0);
    const withdrawal = filteredRecords.filter((r) => r.type === 'withdrawal').reduce((sum, r) => sum + (r.amount || 0), 0);
    const docs = filteredRecords.filter((r) => r.type === 'document').length;
    return { income, expense, loan, withdrawal, docs, totalCount: filteredRecords.length };
  }, [filteredRecords]);

  // Handler to print the current filtered list as an official tabular report
  const handlePrintTableReport = () => {
    if (onPrintReport) {
      const tabTitleMap: Record<SubTab, string> = {
        all: 'ทุกประเภทรายการธุรการและการเงิน',
        document: 'เอกสารและงานสารบรรณ',
        income: 'บันทึกรายรับงบประมาณและรายได้',
        expense: 'บันทึกรายจ่ายและใบเสร็จ',
        loan: 'สินเชื่อสวัสดิการและตารางค่างวด',
        due_date: 'กำหนดชำระและประวัติชำระ',
        withdrawal: 'บันทึกและคำขอเบิกเงิน',
      };
      const authorSummary = isAdmin
        ? (selectedAuthorFilter === 'all' ? 'รวมผู้ใช้งานทุกคน' : `ผู้บันทึก: ${authorList.find((a) => a.id === selectedAuthorFilter)?.name || selectedAuthorFilter}`)
        : `รายการส่วนบุคคล: ${currentUser.fullName}`;

      onPrintReport({
        title: `รายงานสรุปงานธุรการ - ${tabTitleMap[activeSubTab]}`,
        records: filteredRecords,
        filterSummary: `${authorSummary} • ${tabTitleMap[activeSubTab]} • ทั้งหมด ${filteredRecords.length} รายการ`,
      });
    }
  };

  // Open Add Modal
  const handleOpenAdd = (type: RecordType = 'document') => {
    setEditingRecord(null);
    setFormType(type);
    setFormTitle('');
    setFormCategory(
      type === 'document' ? 'บันทึกข้อความ' :
      type === 'income' ? 'รายรับทั่วไป' :
      type === 'expense' ? 'วัสดุสำนักงาน' :
      type === 'loan' ? 'สินเชื่อสวัสดิการ' : 'เบิกค่าใช้จ่าย'
    );
    setFormAmount('');
    setFormDate(new Date().toISOString().split('T')[0]);
    setFormDescription('');
    setFormStatus(type === 'withdrawal' ? 'pending' : 'completed');
    setFormDocNumber('');
    setFormDocType('บันทึกข้อความ');
    setFormSender('');
    setFormReceiver('');
    setFormPaymentMethod('โอนผ่านธนาคาร');
    setFormReferenceNumber('');
    setFormBorrowerName('');
    setFormInstallmentCount('12');
    setFormLoanTermMonths('12');
    setFormDueDate('');
    setFormMonthlyInstallment('');
    setFormApplicantName(currentUser.fullName);
    setAttachments([]);
    setIsAddModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (rec: GeneralRecord) => {
    // Check permission: User can only edit own records
    if (!isAdmin && rec.createdByUserId !== currentUser.id) {
      alert('คุณสามารถแก้ไขได้เฉพาะรายการที่คุณบันทึกเองเท่านั้น');
      return;
    }

    setEditingRecord(rec);
    setFormType(rec.type);
    setFormTitle(rec.title);
    setFormCategory(rec.category);
    setFormAmount(rec.amount ? rec.amount.toString() : '');
    setFormDate(rec.date);
    setFormDescription(rec.description || '');
    setFormStatus(rec.status);
    setFormDocNumber(rec.documentNumber || '');
    setFormDocType(rec.documentType || 'บันทึกข้อความ');
    setFormSender(rec.sender || '');
    setFormReceiver(rec.receiver || '');
    setFormPaymentMethod(rec.paymentMethod || 'โอนผ่านธนาคาร');
    setFormReferenceNumber(rec.referenceNumber || '');
    setFormBorrowerName(rec.borrowerName || '');
    setFormInstallmentCount(rec.installmentCount ? rec.installmentCount.toString() : rec.loanTermMonths ? rec.loanTermMonths.toString() : '12');
    setFormLoanTermMonths(rec.loanTermMonths ? rec.loanTermMonths.toString() : '12');
    setFormDueDate(rec.dueDate || '');
    setFormMonthlyInstallment(rec.monthlyInstallment ? rec.monthlyInstallment.toString() : '');
    setFormApplicantName(rec.applicantName || rec.createdByName);
    setAttachments(rec.attachments || []);
    setIsAddModalOpen(true);
  };

  // Handle File Upload into Base64 Attachment
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const newAtt: FileAttachment = {
          id: 'att-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
          name: file.name,
          size: file.size,
          type: file.type || 'application/octet-stream',
          dataUrl: event.target?.result as string,
          uploadedAt: new Date().toISOString(),
        };
        setAttachments((prev) => [...prev, newAtt]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveAttachment = (attId: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== attId));
  };

  // Save Record
  const handleSaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      alert('กรุณากรอกหัวข้อรายการ');
      return;
    }

    const prefixMap: Record<RecordType, string> = {
      document: 'DOC',
      income: 'REV',
      expense: 'EXP',
      loan: 'LOAN',
      withdrawal: 'WTH',
    };

    const recordNumber = editingRecord
      ? editingRecord.recordNumber
      : `${prefixMap[formType]}-2568-${Math.floor(100 + Math.random() * 900)}`;

    const parsedAmount = formAmount ? parseFloat(formAmount) : undefined;
    const parsedInstallmentCount = formInstallmentCount ? parseInt(formInstallmentCount, 10) : undefined;
    const parsedMonths = formLoanTermMonths ? parseInt(formLoanTermMonths, 10) : undefined;
    const parsedInstallment = formMonthlyInstallment ? parseFloat(formMonthlyInstallment) : undefined;

    const recordData: GeneralRecord = {
      id: editingRecord ? editingRecord.id : 'rec-' + Date.now(),
      recordNumber,
      type: formType,
      title: formTitle.trim(),
      description: formDescription.trim(),
      amount: parsedAmount,
      category: formCategory.trim() || 'ทั่วไป',
      date: formDate,
      status: formStatus,
      
      documentNumber: formDocNumber.trim(),
      documentType: formDocType as any,
      sender: formSender.trim(),
      receiver: formReceiver.trim(),

      paymentMethod: formPaymentMethod,
      referenceNumber: formReferenceNumber.trim(),

      borrowerName: formBorrowerName.trim(),
      installmentCount: parsedInstallmentCount,
      interestRate: editingRecord?.interestRate,
      loanTermMonths: parsedMonths,
      dueDate: formDueDate,
      monthlyInstallment: parsedInstallment,
      totalPaid: editingRecord?.totalPaid || 0,

      applicantName: formApplicantName.trim() || currentUser.fullName,
      approverName: editingRecord?.approverName || (isAdmin && formStatus === 'approved' ? currentUser.fullName : undefined),
      approvalDate: editingRecord?.approvalDate || (isAdmin && formStatus === 'approved' ? new Date().toISOString().split('T')[0] : undefined),
      approvalNote: editingRecord?.approvalNote,

      attachments,
      createdByUserId: editingRecord ? editingRecord.createdByUserId : currentUser.id,
      createdByName: editingRecord ? editingRecord.createdByName : currentUser.fullName,
      createdAt: editingRecord ? editingRecord.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      syncedToGoogleSheet: false,
    };

    onSaveRecord(recordData);
    setIsAddModalOpen(false);
  };

  // Quick Approval for Admin on Withdrawal
  const handleApproveWithdrawal = (rec: GeneralRecord) => {
    if (!isAdmin) return;
    const updated: GeneralRecord = {
      ...rec,
      status: 'approved',
      approverName: currentUser.fullName,
      approvalDate: new Date().toISOString().split('T')[0],
      approvalNote: 'อนุมัติเรียบร้อยโดย ' + currentUser.fullName,
      updatedAt: new Date().toISOString(),
    };
    onSaveRecord(updated);
  };

  // Mark Loan Payment as Paid (วันที่ชำระ)
  const handleRecordPayment = (rec: GeneralRecord) => {
    const installment = rec.monthlyInstallment || 1000;
    const newTotalPaid = (rec.totalPaid || 0) + installment;
    const isCompleted = rec.amount ? newTotalPaid >= rec.amount : false;

    const nextDueDate = new Date();
    nextDueDate.setMonth(nextDueDate.getMonth() + 1);
    const nextDueDateStr = nextDueDate.toISOString().split('T')[0];

    const updated: GeneralRecord = {
      ...rec,
      totalPaid: newTotalPaid,
      dueDate: isCompleted ? '-' : nextDueDateStr,
      status: isCompleted ? 'completed' : 'pending',
      updatedAt: new Date().toISOString(),
    };
    onSaveRecord(updated);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Role Mode Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2.5 flex-wrap gap-y-1">
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                {isAdmin ? 'ศูนย์รวมข้อมูลธุรการและการเงิน (Admin Overview)' : 'บันทึกข้อมูลธุรการ (รายการของฉัน)'}
              </h1>
              {isAdmin ? (
                <span className="inline-flex items-center space-x-1.5 px-3 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
                  <span>👑 แอดมิน: รวมทุกรายการที่บันทึก</span>
                </span>
              ) : (
                <span className="inline-flex items-center space-x-1.5 px-3 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200">
                  <span>👤 รายการส่วนบุคคล: {currentUser.fullName}</span>
                </span>
              )}
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              {isAdmin
                ? 'รวบรวมข้อมูลเอกสาร รายรับ รายจ่าย สินเชื่อ และเบิกเงินจากผู้ใช้งานทุกคนในระบบ สามารถกรองรายบุคคลได้'
                : `ระบบบันทึกเอกสาร รายรับ-จ่าย สินเชื่อ และขอเบิกเงิน (แสดงเฉพาะข้อมูลที่คุณเป็นผู้บันทึก ${filteredRecords.length} รายการ)`}
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {/* Print Table Report Button */}
            <button
              onClick={handlePrintTableReport}
              className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center space-x-2 transition shadow-sm active:scale-98"
              title="พิมพ์รายงานสรุปตารางตามที่กำลังแสดงผล"
            >
              <Printer className="w-4 h-4" />
              <span>พิมพ์รายงานสรุป</span>
            </button>

            {/* Add New Record Button */}
            <button
              onClick={() => handleOpenAdd(activeSubTab === 'all' || activeSubTab === 'due_date' ? 'document' : activeSubTab as RecordType)}
              className="px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center space-x-2 transition shadow-sm active:scale-98"
            >
              <Plus className="w-4 h-4" />
              <span>บันทึกข้อมูลใหม่</span>
            </button>
          </div>
        </div>

        {/* Admin Author Selector (when Admin wants to filter by specific user or view all) */}
        {isAdmin && (
          <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center space-x-2">
              <span className="font-semibold text-slate-700 whitespace-nowrap">แยกรายการตามผู้บันทึก:</span>
              <select
                value={selectedAuthorFilter}
                onChange={(e) => setSelectedAuthorFilter(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-hidden"
              >
                <option value="all">👥 รวมทุกรายการจากทุกคน ({records.length} รายการ)</option>
                {authorList.map((author) => {
                  const count = records.filter(
                    (r) => r.createdByUserId === author.id || r.createdByName === author.name
                  ).length;
                  return (
                    <option key={author.id} value={author.id}>
                      👤 {author.name} ({count} รายการ)
                    </option>
                  );
                })}
              </select>
            </div>

            <div className="text-slate-500 text-[11px]">
              {selectedAuthorFilter === 'all' ? (
                <span className="text-indigo-600 font-medium">● กำลังแสดงทุกรายการบันทึกของทุกคนในองค์กร</span>
              ) : (
                <span className="text-blue-600 font-medium">
                  ● กรองเฉพาะรายการที่บันทึกโดย:{' '}
                  <strong>{authorList.find((a) => a.id === selectedAuthorFilter)?.name}</strong>
                </span>
              )}
            </div>
          </div>
        )}

        {/* Dynamic KPI Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 pt-2">
          <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-xl">
            <div className="text-[11px] font-semibold text-indigo-700 uppercase tracking-wider flex items-center space-x-1">
              <FileText className="w-3.5 h-3.5" />
              <span>รายการทั้งหมด</span>
            </div>
            <div className="text-lg sm:text-xl font-bold text-indigo-950 mt-1">
              {viewStats.totalCount} <span className="text-xs font-normal text-indigo-600">รายการ</span>
            </div>
          </div>

          <div className="p-3 bg-emerald-50/70 border border-emerald-100 rounded-xl">
            <div className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider flex items-center space-x-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>รายรับรวม</span>
            </div>
            <div className="text-lg sm:text-xl font-bold text-emerald-700 mt-1">
              ฿{viewStats.income.toLocaleString()}
            </div>
          </div>

          <div className="p-3 bg-rose-50/70 border border-rose-100 rounded-xl">
            <div className="text-[11px] font-semibold text-rose-700 uppercase tracking-wider flex items-center space-x-1">
              <TrendingDown className="w-3.5 h-3.5" />
              <span>รายจ่ายรวม</span>
            </div>
            <div className="text-lg sm:text-xl font-bold text-rose-700 mt-1">
              ฿{viewStats.expense.toLocaleString()}
            </div>
          </div>

          <div className="p-3 bg-amber-50/70 border border-amber-100 rounded-xl">
            <div className="text-[11px] font-semibold text-amber-800 uppercase tracking-wider flex items-center space-x-1">
              <Landmark className="w-3.5 h-3.5" />
              <span>สินเชื่อสวัสดิการ</span>
            </div>
            <div className="text-lg sm:text-xl font-bold text-amber-800 mt-1">
              ฿{viewStats.loan.toLocaleString()}
            </div>
          </div>

          <div className="p-3 bg-purple-50/70 border border-purple-100 rounded-xl col-span-2 sm:col-span-1">
            <div className="text-[11px] font-semibold text-purple-700 uppercase tracking-wider flex items-center space-x-1">
              <CreditCard className="w-3.5 h-3.5" />
              <span>ขอเบิกเงิน</span>
            </div>
            <div className="text-lg sm:text-xl font-bold text-purple-700 mt-1">
              ฿{viewStats.withdrawal.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Sub-Tabs: ทั้งหมด, เอกสาร, บันทึกรายรับ, บันทึกรายจ่าย, สินเชื่อ, วันที่ชำระ, เบิกเงิน */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 border-b border-slate-100 text-xs sm:text-sm font-medium scrollbar-none">
          {[
            { id: 'all', label: 'ทั้งหมด', icon: FileText, activeClass: 'bg-slate-900 text-white shadow-xs' },
            { id: 'document', label: 'เอกสาร', icon: FileText, activeClass: 'bg-indigo-600 text-white shadow-xs' },
            { id: 'income', label: 'บันทึกรายรับ', icon: TrendingUp, activeClass: 'bg-emerald-600 text-white shadow-xs' },
            { id: 'expense', label: 'บันทึกรายจ่าย', icon: TrendingDown, activeClass: 'bg-rose-600 text-white shadow-xs' },
            { id: 'loan', label: 'สินเชื่อ', icon: Landmark, activeClass: 'bg-amber-600 text-white shadow-xs' },
            { id: 'due_date', label: 'วันที่ชำระ', icon: Calendar, activeClass: 'bg-sky-600 text-white shadow-xs' },
            { id: 'withdrawal', label: 'เบิกเงิน', icon: CreditCard, activeClass: 'bg-purple-600 text-white shadow-xs' },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSubTab === tab.id;
            const count = tab.id === 'all'
              ? (isAdmin && selectedAuthorFilter === 'all' ? records.length : filteredRecords.length)
              : tab.id === 'due_date'
              ? records.filter((r) => r.type === 'loan' || r.dueDate).length
              : records.filter((r) => r.type === tab.id).length;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as SubTab)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl whitespace-nowrap transition text-xs sm:text-sm font-semibold ${
                  isActive
                    ? tab.activeClass
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isActive ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search & Category Filter Toolbar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ค้นหาเอกสาร, รายรับ, รายจ่าย, สินเชื่อ, ผู้ขอเบิก, ผู้บันทึก..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 bg-slate-200 px-1.5 py-0.5 rounded-full"
              >
                ล้าง
              </button>
            )}
          </div>

          <div className="flex items-center space-x-2 text-xs text-slate-500">
            <span>แสดง: <strong className="text-slate-800 font-bold">{filteredRecords.length}</strong> รายการ</span>
          </div>
        </div>
      </div>

      {/* Main Records List / Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-600 font-semibold bg-slate-50/90">
                <th className="py-3.5 px-4">รหัส / วันที่</th>
                <th className="py-3.5 px-4">รายการ / รายละเอียด</th>
                {isAdmin && <th className="py-3.5 px-4">ผู้บันทึก</th>}
                <th className="py-3.5 px-4">หมวดหมู่</th>
                <th className="py-3.5 px-4 text-right">จำนวนเงิน</th>
                <th className="py-3.5 px-4 text-center">วันที่ชำระ / กำหนด</th>
                <th className="py-3.5 px-4 text-center">ไฟล์แนบ</th>
                <th className="py-3.5 px-4 text-center">สถานะ</th>
                <th className="py-3.5 px-4 text-right">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={isAdmin ? 9 : 8} className="py-12 text-center text-slate-400">
                    <FileText className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <div className="font-medium">ยังไม่มีข้อมูลในหมวดนี้ หรือไม่พบผลการค้นหา</div>
                    <button
                      onClick={() => handleOpenAdd(activeSubTab === 'all' || activeSubTab === 'due_date' ? 'document' : activeSubTab as RecordType)}
                      className="mt-3 inline-flex items-center space-x-1 text-xs font-semibold text-blue-600 hover:text-blue-800"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>เพิ่มรายการใหม่ตอนนี้</span>
                    </button>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((r) => {
                  const hasFiles = r.attachments && r.attachments.length > 0;
                  const canManage = isAdmin || r.createdByUserId === currentUser.id;

                  // Creator avatar color
                  const isCreatorAdmin = r.createdByUserId?.includes('admin') || r.createdByName?.includes('Admin');

                  return (
                    <tr key={r.id} className="hover:bg-slate-50/80 transition group">
                      {/* Code & Date */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="font-mono font-bold text-slate-900">{r.recordNumber}</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">{r.date}</div>
                      </td>

                      {/* Title & specific details */}
                      <td className="py-3.5 px-4 min-w-[200px]">
                        <div className="font-semibold text-slate-900 text-sm leading-snug">
                          {r.title}
                        </div>
                        <div className="text-[11px] text-slate-500 mt-1 flex flex-wrap gap-2">
                          {r.type === 'document' && (
                            <>
                              <span>เลขที่: {r.documentNumber || '-'}</span>
                              <span>•</span>
                              <span>ประเภท: {r.documentType}</span>
                              {r.sender && <span>• จาก: {r.sender}</span>}
                            </>
                          )}
                          {r.type === 'income' && (
                            <>
                              <span>วิธี: {r.paymentMethod}</span>
                              {r.referenceNumber && <span>• เลขที่: {r.referenceNumber}</span>}
                            </>
                          )}
                          {r.type === 'expense' && (
                            <>
                              <span>วิธี: {r.paymentMethod}</span>
                              {r.referenceNumber && <span>• เลขที่บิล: {r.referenceNumber}</span>}
                            </>
                          )}
                          {r.type === 'loan' && (
                            <>
                              <span>ผู้กู้: {r.borrowerName}</span>
                              <span>• จำนวนงวด: {r.installmentCount || r.loanTermMonths || '-'} งวด</span>
                              <span>• ชำระแล้ว: ฿{(r.totalPaid || 0).toLocaleString()}</span>
                            </>
                          )}
                          {r.type === 'withdrawal' && (
                            <>
                              <span>ผู้ขอเบิก: {r.applicantName || r.createdByName}</span>
                              {r.approverName && <span>• ผู้อนุมัติ: {r.approverName}</span>}
                            </>
                          )}
                        </div>
                      </td>

                      {/* Creator Author (shown for Admin so they see who submitted it) */}
                      {isAdmin && (
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center space-x-1 text-xs px-2.5 py-1 rounded-full font-medium ${
                              isCreatorAdmin
                                ? 'bg-indigo-100 text-indigo-800'
                                : 'bg-blue-50 text-blue-700 border border-blue-200'
                            }`}
                          >
                            <span>{isCreatorAdmin ? '👑' : '👤'}</span>
                            <span className="truncate max-w-[120px]">{r.createdByName || 'ผู้ใช้งาน'}</span>
                          </span>
                        </td>
                      )}

                      {/* Category */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="bg-slate-100 text-slate-700 text-xs px-2.5 py-1 rounded-full font-medium">
                          {r.category}
                        </span>
                      </td>

                      {/* Amount */}
                      <td className="py-3.5 px-4 text-right font-bold whitespace-nowrap">
                        {r.amount != null ? (
                          <span className={
                            r.type === 'income' ? 'text-emerald-600 font-bold' :
                            r.type === 'expense' ? 'text-rose-600 font-bold' :
                            r.type === 'loan' ? 'text-amber-800 font-bold' :
                            r.type === 'withdrawal' ? 'text-purple-700 font-bold' : 'text-slate-800'
                          }>
                            {r.type === 'income' ? '+' : r.type === 'expense' ? '-' : ''}
                            ฿{r.amount.toLocaleString()}
                          </span>
                        ) : (
                          <span className="text-slate-400 font-normal">-</span>
                        )}
                      </td>

                      {/* Due date / Payment tracking */}
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        {r.type === 'loan' ? (
                          <div>
                            <span className="text-xs font-semibold text-slate-800 block">
                              {r.dueDate || '-'}
                            </span>
                            {canManage && r.status !== 'completed' && (
                              <button
                                onClick={() => handleRecordPayment(r)}
                                className="mt-1 text-[10px] bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold px-2 py-0.5 rounded border border-emerald-200 transition"
                                title="บันทึกชำระค่างวด 1 งวด"
                              >
                                บันทึกชำระงวด
                              </button>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-400 text-xs">{r.dueDate || '-'}</span>
                        )}
                      </td>

                      {/* Attachments (ดูไฟล์ได้) */}
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        {hasFiles ? (
                          <button
                            onClick={() => onViewFile(r)}
                            className="inline-flex items-center space-x-1 px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-medium transition"
                            title="ดูไฟล์แนบ"
                          >
                            <Paperclip className="w-3.5 h-3.5" />
                            <span>ดูไฟล์ ({r.attachments.length})</span>
                          </button>
                        ) : (
                          <span className="text-slate-300 text-xs">-</span>
                        )}
                      </td>

                      {/* Status & Approval */}
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-medium ${
                          r.status === 'completed' || r.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : r.status === 'pending'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}>
                          {r.status === 'completed' && 'เรียบร้อย'}
                          {r.status === 'approved' && 'อนุมัติแล้ว'}
                          {r.status === 'pending' && 'รอชำระ / รออนุมัติ'}
                          {r.status === 'rejected' && 'ไม่อนุมัติ'}
                          {r.status === 'cancelled' && 'ยกเลิก'}
                        </span>

                        {/* Admin quick approval button on pending withdrawal */}
                        {isAdmin && r.type === 'withdrawal' && r.status === 'pending' && (
                          <button
                            onClick={() => handleApproveWithdrawal(r)}
                            className="block mx-auto mt-1 text-[10px] bg-indigo-600 hover:bg-indigo-700 text-white px-2 py-0.5 rounded font-semibold transition shadow-2xs"
                          >
                            กดอนุมัติ
                          </button>
                        )}
                      </td>

                      {/* Actions: Print, Edit, Delete */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end space-x-1.5">
                          {/* พิมพ์รายการ (Print this record) */}
                          <button
                            onClick={() => onPrintRecord(r)}
                            className="p-1.5 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition border border-emerald-200"
                            title="พิมพ์เอกสาร / ใบสำคัญนี้"
                          >
                            <Printer className="w-4 h-4" />
                          </button>

                          {/* แก้ไขรายการ */}
                          {canManage && (
                            <button
                              onClick={() => handleOpenEdit(r)}
                              className="p-1.5 text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg transition border border-amber-200"
                              title="แก้ไขรายการ"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                          )}

                          {/* ลบรายการ */}
                          {canManage && (
                            <button
                              onClick={() => setRecordToDelete(r)}
                              className="p-1.5 text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg transition border border-rose-200"
                              title="ลบรายการ"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD / EDIT MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full my-6 flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 bg-slate-800 text-white">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <FileText className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-bold">
                    {editingRecord ? 'แก้ไขรายการธุรการ' : 'บันทึกข้อมูลธุรการใหม่'}
                  </h2>
                  <p className="text-xs text-slate-300">
                    บันทึกข้อมูลเข้าสู่ระบบ E-OFFICE (และซิงค์ไปยัง Google Sheet ตามการตั้งค่า)
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveSubmit} className="p-6 overflow-y-auto max-h-[75vh] space-y-4">
              {/* Type Selector (only on create) */}
              {!editingRecord && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                    เลือกประเภทรายการ
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {[
                      { id: 'document', label: 'เอกสาร' },
                      { id: 'income', label: 'บันทึกรายรับ' },
                      { id: 'expense', label: 'บันทึกรายจ่าย' },
                      { id: 'loan', label: 'สินเชื่อ' },
                      { id: 'withdrawal', label: 'เบิกเงิน' },
                    ].map((t) => (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => {
                          setFormType(t.id as RecordType);
                          setFormCategory(
                            t.id === 'document' ? 'บันทึกข้อความ' :
                            t.id === 'income' ? 'รายรับทั่วไป' :
                            t.id === 'expense' ? 'วัสดุสำนักงาน' :
                            t.id === 'loan' ? 'สินเชื่อสวัสดิการ' : 'เบิกค่าใช้จ่าย'
                          );
                        }}
                        className={`py-2 px-2 text-xs font-semibold rounded-xl border text-center transition ${
                          formType === t.id
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Title & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    หัวข้อ / รายการ <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    placeholder="เช่น ค่าจัดซื้อวัสดุสำนักงาน, คำสั่งแต่งตั้ง..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    วันที่ทำรายการ
                  </label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-hidden"
                  />
                </div>
              </div>

              {/* Category & Amount */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    หมวดหมู่
                  </label>
                  <input
                    type="text"
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    placeholder="เช่น วัสดุสำนักงาน, ค่าพาหนะ, สัญญา..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-hidden"
                  />
                </div>

                {formType !== 'document' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      จำนวนเงิน (บาท) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      required
                      value={formAmount}
                      onChange={(e) => setFormAmount(e.target.value)}
                      placeholder="0.00"
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-hidden font-mono"
                    />
                  </div>
                )}
              </div>

              {/* Type-Specific Fields */}
              {formType === 'document' && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <div className="text-xs font-bold text-slate-700">ข้อมูลสารบรรณและหนังสือ</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">เลขที่หนังสือ</label>
                      <input
                        type="text"
                        value={formDocNumber}
                        onChange={(e) => setFormDocNumber(e.target.value)}
                        placeholder="เช่น ศธ 04123/ว 114"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">ประเภทหนังสือ</label>
                      <select
                        value={formDocType}
                        onChange={(e) => setFormDocType(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      >
                        <option value="หนังสือเข้า">หนังสือเข้า</option>
                        <option value="หนังสือออก">หนังสือออก</option>
                        <option value="คำสั่ง">คำสั่ง</option>
                        <option value="บันทึกข้อความ">บันทึกข้อความ</option>
                        <option value="สัญญา">สัญญา</option>
                        <option value="อื่นๆ">อื่นๆ</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">จาก (ผู้ส่ง)</label>
                      <input
                        type="text"
                        value={formSender}
                        onChange={(e) => setFormSender(e.target.value)}
                        placeholder="หน่วยงาน/ชื่อผู้ส่ง"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">ถึง (ผู้รับ)</label>
                      <input
                        type="text"
                        value={formReceiver}
                        onChange={(e) => setFormReceiver(e.target.value)}
                        placeholder="หน่วยงาน/ชื่อผู้รับ"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                  </div>
                </div>
              )}

              {(formType === 'income' || formType === 'expense') && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <div className="text-xs font-bold text-slate-700">ข้อมูลการเงินและใบเสร็จ</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">วิธีการชำระ</label>
                      <select
                        value={formPaymentMethod}
                        onChange={(e) => setFormPaymentMethod(e.target.value as any)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      >
                        <option value="โอนผ่านธนาคาร">โอนผ่านธนาคาร</option>
                        <option value="เงินสด">เงินสด</option>
                        <option value="เช็ค">เช็ค</option>
                        <option value="บัตรเครดิต">บัตรเครดิต</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">เลขที่ใบเสร็จ / ใบแจ้งหนี้ / สลิป</label>
                      <input
                        type="text"
                        value={formReferenceNumber}
                        onChange={(e) => setFormReferenceNumber(e.target.value)}
                        placeholder="เช่น RC-2568-009"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                  </div>
                </div>
              )}

              {formType === 'loan' && (
                <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-3">
                  <div className="text-xs font-bold text-amber-900">ข้อมูลสัญญาสินเชื่อและวันที่ชำระ</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-700 mb-1">ชื่อผู้กู้ยืม</label>
                      <input
                        type="text"
                        required
                        value={formBorrowerName}
                        onChange={(e) => setFormBorrowerName(e.target.value)}
                        placeholder="ชื่อ-นามสกุลผู้กู้"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-700 mb-1">วันที่ต้องชำระงวด (Due Date)</label>
                      <input
                        type="date"
                        value={formDueDate}
                        onChange={(e) => setFormDueDate(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-700 mb-1">จำนวนงวด (งวด)</label>
                      <input
                        type="number"
                        min="1"
                        value={formInstallmentCount}
                        onChange={(e) => setFormInstallmentCount(e.target.value)}
                        placeholder="เช่น 12"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-700 mb-1">ค่างวดต่อเดือน (บาท)</label>
                      <input
                        type="number"
                        value={formMonthlyInstallment}
                        onChange={(e) => setFormMonthlyInstallment(e.target.value)}
                        placeholder="เช่น 5,000"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                  </div>
                </div>
              )}

              {formType === 'withdrawal' && (
                <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-3">
                  <div className="text-xs font-bold text-indigo-900">ข้อมูลการขอเบิกเงิน</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-700 mb-1">ชื่อผู้ขอเบิก</label>
                      <input
                        type="text"
                        value={formApplicantName}
                        onChange={(e) => setFormApplicantName(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-700 mb-1">สถานะคำขอ</label>
                      <select
                        disabled={!isAdmin}
                        value={formStatus}
                        onChange={(e) => setFormStatus(e.target.value as any)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs disabled:bg-slate-100"
                      >
                        <option value="pending">รอดำเนินการ / รออนุมัติ</option>
                        <option value="approved">อนุมัติแล้ว</option>
                        <option value="completed">จ่ายเงินเรียบร้อย</option>
                        <option value="rejected">ไม่อนุมัติ</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  รายละเอียดเพิ่มเติม
                </label>
                <textarea
                  rows={3}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="วัตถุประสงค์, ข้อความสรุป หรือหมายเหตุ..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-hidden"
                />
              </div>

              {/* Attach File Section (แนบไฟล์) */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
                  <span>แนบไฟล์เอกสาร (PDF, รูปภาพสลิป, เอกสารประกอบ)</span>
                  <span className="text-[11px] text-slate-400 font-normal">แนบได้หลายไฟล์</span>
                </label>
                
                <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-4 text-center cursor-pointer transition bg-slate-50 relative">
                  <input
                    type="file"
                    multiple
                    onChange={handleFileUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                  />
                  <Upload className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                  <span className="text-xs text-blue-600 font-semibold">คลิกเลือกไฟล์ หรือลากไฟล์มาวางที่นี่</span>
                  <p className="text-[11px] text-slate-400 mt-0.5">รองรับไฟล์ PDF, JPG, PNG, DOC (ดูไฟล์ได้ทันที)</p>
                </div>

                {/* Attachments List */}
                {attachments.length > 0 && (
                  <div className="mt-3 space-y-1.5">
                    {attachments.map((att) => (
                      <div
                        key={att.id}
                        className="flex items-center justify-between p-2 bg-slate-100 rounded-lg text-xs"
                      >
                        <div className="flex items-center space-x-2 truncate">
                          <Paperclip className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          <span className="font-medium text-slate-800 truncate">{att.name}</span>
                          <span className="text-slate-400 text-[10px]">({(att.size / 1024).toFixed(0)} KB)</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveAttachment(att.id)}
                          className="p-1 text-slate-400 hover:text-red-600 rounded"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Modal Buttons */}
              <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div>
                  {editingRecord && (
                    <button
                      type="button"
                      onClick={() => onPrintRecord(editingRecord)}
                      className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs sm:text-sm font-semibold rounded-xl transition flex items-center space-x-1.5"
                    >
                      <Printer className="w-4 h-4" />
                      <span>พิมพ์เอกสารนี้</span>
                    </button>
                  )}
                </div>

                <div className="flex items-center space-x-3">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl transition"
                  >
                    ยกเลิก
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition shadow-md shadow-blue-500/20"
                  >
                    {editingRecord ? 'บันทึกการแก้ไข' : 'บันทึกข้อมูล'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {recordToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-center space-y-4">
            <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">ยืนยันการลบรายการ?</h3>
              <p className="text-sm text-slate-600 mt-1">
                คุณแน่ใจหรือไม่ว่าต้องการลบรายการ <strong className="text-slate-800 font-semibold">{recordToDelete.recordNumber} - {recordToDelete.title}</strong>
              </p>
              <p className="text-xs text-rose-600 mt-1">การกระทำนี้ไม่สามารถย้อนกลับได้</p>
            </div>
            <div className="flex items-center justify-center space-x-3 pt-2">
              <button
                onClick={() => setRecordToDelete(null)}
                className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl transition"
              >
                ยกเลิก
              </button>
              <button
                onClick={() => {
                  onDeleteRecord(recordToDelete.id);
                  setRecordToDelete(null);
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold rounded-xl transition shadow-sm"
              >
                ยืนยันการลบ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
