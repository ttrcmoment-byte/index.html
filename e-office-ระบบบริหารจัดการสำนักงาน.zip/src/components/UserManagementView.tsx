import React, { useState } from 'react';
import { AppUser, UserRole } from '../types';
import { 
  Users, 
  UserPlus, 
  Key, 
  Edit3, 
  Trash2, 
  Shield, 
  User, 
  Lock, 
  Check, 
  X, 
  AlertTriangle,
  Phone,
  Mail,
  Building
} from 'lucide-react';

interface UserManagementViewProps {
  users: AppUser[];
  currentUser: AppUser;
  onSaveUser: (user: AppUser) => void;
  onDeleteUser: (userId: string) => void;
  onUpdateCurrentUser: (user: AppUser) => void;
  onLogout: () => void;
}

export const UserManagementView: React.FC<UserManagementViewProps> = ({
  users,
  currentUser,
  onSaveUser,
  onDeleteUser,
  onUpdateCurrentUser,
  onLogout,
}) => {
  const isAdmin = currentUser.role === 'admin';

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<AppUser | null>(null);
  const [userToDelete, setUserToDelete] = useState<AppUser | null>(null);

  // Form states
  const [formUsername, setFormUsername] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formFullName, setFormFullName] = useState('');
  const [formRole, setFormRole] = useState<UserRole>('user');
  const [formDepartment, setFormDepartment] = useState('');
  const [formPosition, setFormPosition] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');

  // Password change modal for quick password reset
  const [passwordResetUser, setPasswordResetUser] = useState<AppUser | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');

  // Open Create Modal
  const handleOpenCreate = () => {
    setEditingUser(null);
    setFormUsername('');
    setFormPassword('');
    setFormFullName('');
    setFormRole('user');
    setFormDepartment('ฝ่ายธุรการ');
    setFormPosition('เจ้าหน้าที่ธุรการ');
    setFormPhone('');
    setFormEmail('');
    setIsModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (u: AppUser) => {
    setEditingUser(u);
    setFormUsername(u.username);
    setFormPassword(u.password);
    setFormFullName(u.fullName);
    setFormRole(u.role);
    setFormDepartment(u.department || '');
    setFormPosition(u.position || '');
    setFormPhone(u.phone || '');
    setFormEmail(u.email || '');
    setIsModalOpen(true);
  };

  const handleSaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formUsername.trim() || !formFullName.trim()) {
      alert('กรุณากรอกชื่อผู้ใช้และชื่อ-นามสกุล');
      return;
    }

    // Check duplicate username if new user
    if (!editingUser) {
      const exists = users.some(u => u.username.toLowerCase() === formUsername.trim().toLowerCase());
      if (exists) {
        alert('ชื่อผู้ใช้งานนี้มีอยู่ในระบบแล้ว กรุณาใช้ชื่ออื่น');
        return;
      }
    }

    const userData: AppUser = {
      id: editingUser ? editingUser.id : 'user-' + Date.now(),
      username: formUsername.trim(),
      password: formPassword.trim() || (editingUser ? editingUser.password : '123456'),
      fullName: formFullName.trim(),
      role: isAdmin ? formRole : editingUser?.role || 'user',
      department: formDepartment.trim(),
      position: formPosition.trim(),
      phone: formPhone.trim(),
      email: formEmail.trim(),
      createdAt: editingUser ? editingUser.createdAt : new Date().toISOString(),
      status: 'active',
    };

    onSaveUser(userData);

    // If edited own user profile
    if (editingUser && editingUser.id === currentUser.id) {
      onUpdateCurrentUser(userData);
    }

    setIsModalOpen(false);
  };

  // Quick Password Reset
  const handleSavePasswordReset = () => {
    if (!passwordResetUser || !newPasswordInput.trim()) return;
    const updated: AppUser = {
      ...passwordResetUser,
      password: newPasswordInput.trim(),
    };
    onSaveUser(updated);
    if (passwordResetUser.id === currentUser.id) {
      onUpdateCurrentUser(updated);
    }
    setPasswordResetUser(null);
    setNewPasswordInput('');
    alert('เปลี่ยนรหัสผ่านเรียบร้อยแล้ว');
  };

  // Delete User handler
  const handleConfirmDelete = () => {
    if (!userToDelete) return;
    
    if (userToDelete.id === currentUser.id && isAdmin) {
      alert('ไม่สามารถลบบัญชีผู้ดูแลระบบที่กำลังเข้าสู่ระบบอยู่ได้');
      setUserToDelete(null);
      return;
    }

    const isSelf = userToDelete.id === currentUser.id;
    onDeleteUser(userToDelete.id);
    setUserToDelete(null);

    if (isSelf) {
      alert('บัญชีของคุณถูกลบเรียบร้อยแล้ว กำลังออกจากระบบ...');
      onLogout();
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center space-x-2">
            <Users className="w-6 h-6 text-blue-600" />
            <span>{isAdmin ? 'จัดการผู้ใช้งานในระบบ (ผู้ดูแลระบบ)' : 'จัดการข้อมูลบัญชีของฉัน'}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {isAdmin
              ? 'หน้าแอดมินแสดงรายการทั้งหมด แอดมินสามารถกำหนดผู้ใช้งาน แก้ไข หรือลบ และกำหนดรหัสผ่าน'
              : 'แสดงเฉพาะข้อมูลบัญชีของผู้ใช้ แก้ไขข้อมูลส่วนตัว เปลี่ยนรหัสผ่าน หรือขอลบบัญชี'}
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={handleOpenCreate}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold flex items-center justify-center space-x-2 transition shadow-md shadow-blue-500/20 active:scale-98 shrink-0"
          >
            <UserPlus className="w-4 h-4" />
            <span>เพิ่มผู้ใช้งานใหม่</span>
          </button>
        )}
      </div>

      {/* USER LIST (For Admin: All users; For User: only own account) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {(isAdmin ? users : [currentUser]).map((u) => {
          const isMe = u.id === currentUser.id;
          return (
            <div
              key={u.id}
              className={`bg-white rounded-2xl border p-5 shadow-xs transition flex flex-col justify-between ${
                isMe ? 'border-blue-300 ring-2 ring-blue-500/10' : 'border-slate-200'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-2xl bg-slate-800 text-white flex items-center justify-center font-bold text-lg">
                      {u.fullName.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <h3 className="font-bold text-slate-900 text-base">{u.fullName}</h3>
                        {isMe && (
                          <span className="text-[10px] bg-blue-600 text-white px-1.5 py-0.2 rounded font-bold">
                            ฉัน
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500">@{u.username}</p>
                    </div>
                  </div>

                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    u.role === 'admin'
                      ? 'bg-amber-100 text-amber-800 border border-amber-300'
                      : 'bg-slate-100 text-slate-700'
                  }`}>
                    {u.role.toUpperCase()}
                  </span>
                </div>

                {/* Details */}
                <div className="space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-3">
                  <div className="flex items-center space-x-2">
                    <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{u.department} ({u.position})</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{u.phone || '-'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{u.email || '-'}</span>
                  </div>
                  {isAdmin && (
                    <div className="flex items-center space-x-2 text-slate-500 font-mono text-[11px] bg-slate-50 p-1.5 rounded">
                      <Lock className="w-3 h-3 text-slate-400" />
                      <span>รหัสผ่าน: {u.password}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => {
                    setPasswordResetUser(u);
                    setNewPasswordInput('');
                  }}
                  className="inline-flex items-center space-x-1 text-xs text-blue-600 hover:text-blue-800 font-medium"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>เปลี่ยนรหัส</span>
                </button>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleOpenEdit(u)}
                    className="p-1.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                    title="แก้ไขข้อมูล"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setUserToDelete(u)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                    title="ลบบัญชี"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* CREATE / EDIT USER MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="font-bold text-lg text-slate-900">
                {editingUser ? 'แก้ไขข้อมูลผู้ใช้' : 'เพิ่มผู้ใช้งานใหม่'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ชื่อผู้ใช้งาน (Username) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!!editingUser && !isAdmin}
                    value={formUsername}
                    onChange={(e) => setFormUsername(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm disabled:bg-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    รหัสผ่านเข้าใช้งาน <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formPassword}
                    onChange={(e) => setFormPassword(e.target.value)}
                    placeholder="รหัสผ่าน"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  ชื่อ - นามสกุล <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formFullName}
                  onChange={(e) => setFormFullName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                />
              </div>

              {isAdmin && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ระดับสิทธิ์ (Role)
                  </label>
                  <select
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  >
                    <option value="user">User (ผู้ใช้งานทั่วไป)</option>
                    <option value="admin">Admin (ผู้ดูแลระบบ)</option>
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ฝ่าย / แผนก</label>
                  <input
                    type="text"
                    value={formDepartment}
                    onChange={(e) => setFormDepartment(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ตำแหน่ง</label>
                  <input
                    type="text"
                    value={formPosition}
                    onChange={(e) => setFormPosition(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">เบอร์โทรศัพท์</label>
                  <input
                    type="text"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">อีเมล</label>
                  <input
                    type="email"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-sm"
                >
                  บันทึกข้อมูล
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QUICK PASSWORD RESET MODAL */}
      {passwordResetUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6 space-y-4">
            <div className="flex items-center space-x-2 text-slate-900 font-bold">
              <Key className="w-5 h-5 text-amber-600" />
              <span>กำหนดรหัสผ่านใหม่</span>
            </div>
            <p className="text-xs text-slate-600">
              กำหนดรหัสผ่านสำหรับ <strong>{passwordResetUser.fullName}</strong> (@{passwordResetUser.username})
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                รหัสผ่านใหม่
              </label>
              <input
                type="text"
                autoFocus
                value={newPasswordInput}
                onChange={(e) => setNewPasswordInput(e.target.value)}
                placeholder="ระบุรหัสผ่านใหม่..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-mono"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setPasswordResetUser(null)}
                className="px-3 py-1.5 border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg"
              >
                ยกเลิก
              </button>
              <button
                onClick={handleSavePasswordReset}
                disabled={!newPasswordInput.trim()}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs"
              >
                บันทึกรหัสผ่าน
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-center space-y-4">
            <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                {userToDelete.id === currentUser.id ? 'ยืนยันการลบบัญชีของคุณ?' : 'ยืนยันการลบผู้ใช้?'}
              </h3>
              <p className="text-sm text-slate-600 mt-1">
                คุณแน่ใจหรือไม่ว่าต้องการลบผู้ใช้ <strong>{userToDelete.fullName}</strong> (@{userToDelete.username}) ออกจากระบบ
              </p>
            </div>
            <div className="flex items-center justify-center space-x-3 pt-2">
              <button
                onClick={() => setUserToDelete(null)}
                className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl"
              >
                ยกเลิก
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold rounded-xl shadow-sm"
              >
                ยืนยันการลบ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
