import React from 'react';
import { ActiveTab, UserRole } from '../types';
import { 
  LayoutDashboard, 
  FileText, 
  Users, 
  UserCheck, 
  FileSpreadsheet, 
  ShieldAlert, 
  X,
  Smartphone
} from 'lucide-react';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  role: UserRole;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  onOpenSheetModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  role,
  isMobileOpen,
  onCloseMobile,
  onOpenSheetModal,
}) => {
  const isAdmin = role === 'admin';

  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'แดชบอร์ด',
      icon: LayoutDashboard,
      desc: 'สรุปภาพรวม ค้นหา และส่งออกข้อมูล',
    },
    {
      id: 'general' as ActiveTab,
      label: 'ธุรการ',
      icon: FileText,
      desc: 'เอกสาร, รายรับ-จ่าย, สินเชื่อ, เบิกเงิน',
    },
    ...(isAdmin
      ? [
          {
            id: 'personnel' as ActiveTab,
            label: 'งานบุคคล',
            icon: UserCheck,
            desc: 'ข้อมูลและประวัติบุคลากร',
          },
        ]
      : []),
    {
      id: 'users' as ActiveTab,
      label: isAdmin ? 'จัดการผู้ใช้ (ทั้งหมด)' : 'ข้อมูลบัญชีของฉัน',
      icon: Users,
      desc: isAdmin ? 'กำหนด แก้ไข ลบผู้ใช้ในระบบ' : 'ดูและแก้ไขข้อมูลบัญชีส่วนตัว',
    },
  ];

  const handleSelect = (tab: ActiveTab) => {
    setActiveTab(tab);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Sidebar Content */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:z-auto ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Mobile Header in Drawer */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 lg:hidden">
          <span className="font-bold text-slate-800">เมนูหลัก E-OFFICE</span>
          <button
            onClick={onCloseMobile}
            className="p-1.5 text-slate-500 hover:text-slate-700 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation List */}
        <div className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
          <div className="px-3 mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            ระบบงานหลัก
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-left transition ${
                  isActive
                    ? 'bg-blue-600 text-white font-medium shadow-sm shadow-blue-500/20'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-5 h-5 shrink-0 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                <div className="min-w-0 flex-1">
                  <div className="text-sm truncate">{item.label}</div>
                  <div
                    className={`text-[10px] truncate ${
                      isActive ? 'text-blue-100' : 'text-slate-400'
                    }`}
                  >
                    {item.desc}
                  </div>
                </div>
              </button>
            );
          })}

          {/* Admin Google Sheet Section */}
          {isAdmin && (
            <div className="pt-6 mt-6 border-t border-slate-200 space-y-2">
              <div className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                ระบบเชื่อมต่อ Google Sheet
              </div>
              <button
                onClick={() => {
                  onOpenSheetModal();
                  onCloseMobile();
                }}
                className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-left bg-emerald-50 hover:bg-emerald-100 text-emerald-800 transition border border-emerald-200/80"
              >
                <FileSpreadsheet className="w-5 h-5 text-emerald-600 shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold truncate">เชื่อมโยง Google Sheet</div>
                  <div className="text-[10px] text-emerald-700 truncate">วิธีเปิดระบบ & ซิงค์อัตโนมัติ</div>
                </div>
              </button>
            </div>
          )}
        </div>

        {/* Sidebar Footer Info */}
        <div className="p-4 border-t border-slate-200 bg-slate-50/50">
          <div className="flex items-center space-x-2 text-xs text-slate-500">
            <Smartphone className="w-4 h-4 text-slate-400" />
            <span>รองรับการใช้งานบนมือถือ</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-1">
            Google Sheet ID: 1n2n7...amZw
          </p>
        </div>
      </aside>
    </>
  );
};
