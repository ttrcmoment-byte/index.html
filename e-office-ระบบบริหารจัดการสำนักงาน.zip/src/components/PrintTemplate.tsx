import React from 'react';
import { GeneralRecord, AppUser } from '../types';
import { Printer, X, FileText, CheckCircle2, ShieldAlert } from 'lucide-react';
import { thaiBahtText } from '../utils/thaiBaht';

export interface PrintReportPayload {
  title: string;
  records: GeneralRecord[];
  filterSummary?: string;
}

interface PrintTemplateProps {
  record?: GeneralRecord | null;
  reportData?: PrintReportPayload | null;
  currentUser: AppUser;
  onClose: () => void;
}

export const PrintTemplate: React.FC<PrintTemplateProps> = ({
  record,
  reportData,
  currentUser,
  onClose,
}) => {
  if (!record && !reportData) return null;

  const handlePrint = () => {
    window.print();
  };

  // Helper for single record title
  const getDocTypeName = (r: GeneralRecord) => {
    switch (r.type) {
      case 'document':
        return r.documentType === 'คำสั่ง'
          ? 'คำสั่งสำนักงาน (OFFICIAL ORDER)'
          : 'บันทึกข้อความราชการ (MEMORANDUM)';
      case 'income':
        return 'ใบสำคัญรับเงิน (RECEIPT VOUCHER)';
      case 'expense':
        return 'ใบสำคัญจ่ายเงิน (PAYMENT VOUCHER)';
      case 'loan':
        return 'สัญญาสินเชื่อสวัสดิการและตารางผ่อนชำระ (LOAN AGREEMENT)';
      case 'withdrawal':
        return 'ใบขออนุมัติเบิกจ่ายเงินสวัสดิการ / ค่าใช้จ่าย (REQUISITION SLIP)';
      default:
        return 'เอกสารรายงานระบบสำนักงานอิเล็กทรอนิกส์';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden flex flex-col my-4 max-h-[95vh]">
        {/* Action bar (hidden in print) */}
        <div className="no-print flex items-center justify-between px-6 py-3.5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white shrink-0 border-b border-slate-700">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/30 border border-blue-400/40 flex items-center justify-center">
              <Printer className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <span className="font-semibold text-sm">พิมพ์เอกสารทางการ E-OFFICE</span>
              <span className="text-xs text-slate-400 ml-2 hidden sm:inline">
                (รองรับขนาดกระดาษมาตรฐาน A4 และส่งออก PDF)
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-sm font-semibold rounded-xl flex items-center space-x-2 transition shadow-md shadow-blue-500/20 active:scale-95 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>สั่งพิมพ์ / บันทึกเป็น PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
              aria-label="ปิด"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Official Document Sheet */}
        <div className="p-6 sm:p-10 text-slate-900 bg-white overflow-y-auto" id="printable-record-area">
          
          {/* ========================================================================= */}
          {/* MODE 1: BATCH / SUMMARY TABLE REPORT PRINT */}
          {/* ========================================================================= */}
          {reportData ? (
            <div className="space-y-6">
              {/* Report Header */}
              <div className="border-b-2 border-slate-900 pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h1 className="text-xl font-bold tracking-tight text-slate-900">
                      ระบบบริหารงานสำนักงานอิเล็กทรอนิกส์ E-OFFICE
                    </h1>
                    <h2 className="text-lg font-semibold text-indigo-900 mt-1">
                      {reportData.title}
                    </h2>
                    {reportData.filterSummary && (
                      <p className="text-xs text-slate-600 mt-0.5">
                        เงื่อนไข: {reportData.filterSummary}
                      </p>
                    )}
                  </div>
                  <div className="text-right text-xs text-slate-600">
                    <p className="font-semibold text-slate-800">วันที่พิมพ์: {new Date().toLocaleDateString('th-TH', { dateStyle: 'long' })}</p>
                    <p className="text-slate-500 mt-0.5">พิมพ์โดย: {currentUser.fullName}</p>
                    <p className="text-slate-500">จำนวน: {reportData.records.length} รายการ</p>
                  </div>
                </div>

                {/* Summary Totals Row */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4 pt-3 border-t border-slate-200 text-xs">
                  <div className="p-2.5 bg-emerald-50 rounded-lg border border-emerald-200">
                    <span className="text-emerald-800 block font-medium">รวมยอดรายรับ:</span>
                    <span className="text-sm font-bold text-emerald-700">
                      ฿{reportData.records
                        .filter(r => r.type === 'income')
                        .reduce((sum, r) => sum + (r.amount || 0), 0)
                        .toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="p-2.5 bg-rose-50 rounded-lg border border-rose-200">
                    <span className="text-rose-800 block font-medium">รวมยอดรายจ่าย:</span>
                    <span className="text-sm font-bold text-rose-700">
                      ฿{reportData.records
                        .filter(r => r.type === 'expense')
                        .reduce((sum, r) => sum + (r.amount || 0), 0)
                        .toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200">
                    <span className="text-amber-800 block font-medium">รวมยอดสินเชื่อ:</span>
                    <span className="text-sm font-bold text-amber-700">
                      ฿{reportData.records
                        .filter(r => r.type === 'loan')
                        .reduce((sum, r) => sum + (r.amount || 0), 0)
                        .toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="p-2.5 bg-purple-50 rounded-lg border border-purple-200">
                    <span className="text-purple-800 block font-medium">รวมยอดขอเบิกเงิน:</span>
                    <span className="text-sm font-bold text-purple-700">
                      ฿{reportData.records
                        .filter(r => r.type === 'withdrawal')
                        .reduce((sum, r) => sum + (r.amount || 0), 0)
                        .toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              </div>

              {/* Records Table */}
              <div className="border border-slate-300 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 border-b border-slate-300 font-semibold">
                      <th className="py-2.5 px-3 w-10 text-center">#</th>
                      <th className="py-2.5 px-3 w-28">เลขที่/วันที่</th>
                      <th className="py-2.5 px-3 w-24">ประเภท</th>
                      <th className="py-2.5 px-3">รายการ / รายละเอียด</th>
                      <th className="py-2.5 px-3 w-28">ผู้บันทึก</th>
                      <th className="py-2.5 px-3 w-20 text-center">สถานะ</th>
                      <th className="py-2.5 px-3 w-28 text-right">จำนวนเงิน</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {reportData.records.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-6 text-center text-slate-500">
                          ไม่พบรายการที่ตรงกับเงื่อนไข
                        </td>
                      </tr>
                    ) : (
                      reportData.records.map((r, idx) => (
                        <tr key={r.id} className={idx % 2 === 1 ? 'bg-slate-50/70' : 'bg-white'}>
                          <td className="py-2 px-3 text-center text-slate-500 font-mono">{idx + 1}</td>
                          <td className="py-2 px-3">
                            <span className="font-medium text-slate-900 block font-mono">{r.recordNumber}</span>
                            <span className="text-[11px] text-slate-500">{r.date}</span>
                          </td>
                          <td className="py-2 px-3">
                            <span className="font-medium text-slate-800">
                              {r.type === 'document' && 'สารบรรณ'}
                              {r.type === 'income' && 'รายรับ'}
                              {r.type === 'expense' && 'รายจ่าย'}
                              {r.type === 'loan' && 'สินเชื่อ'}
                              {r.type === 'withdrawal' && 'ขอเบิกเงิน'}
                            </span>
                          </td>
                          <td className="py-2 px-3">
                            <span className="font-semibold text-slate-900 block">{r.title}</span>
                            {r.borrowerName && (
                              <span className="text-[11px] text-slate-500 block">
                                ผู้กู้: {r.borrowerName} • {r.installmentCount || r.loanTermMonths} งวด
                              </span>
                            )}
                            {r.documentNumber && (
                              <span className="text-[11px] text-slate-500 block">
                                เลขที่หนังสือ: {r.documentNumber}
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-3 text-slate-700">{r.createdByName}</td>
                          <td className="py-2 px-3 text-center">
                            <span className="text-[11px] font-medium text-slate-700">
                              {r.status === 'completed' && 'สมบูรณ์'}
                              {r.status === 'approved' && 'อนุมัติ'}
                              {r.status === 'pending' && 'รอตรวจ'}
                              {r.status === 'rejected' && 'ไม่อนุมัติ'}
                              {r.status === 'cancelled' && 'ยกเลิก'}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-right font-semibold">
                            {r.amount !== undefined ? (
                              <span className={
                                r.type === 'income' ? 'text-emerald-700' :
                                r.type === 'expense' ? 'text-rose-700' :
                                r.type === 'loan' ? 'text-amber-700' : 'text-purple-700'
                              }>
                                ฿{r.amount.toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                              </span>
                            ) : (
                              <span className="text-slate-400">-</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Official Signature Sign-offs for Report */}
              <div className="mt-10 pt-6 border-t border-slate-300 grid grid-cols-2 gap-8 text-center text-xs print-break-inside-avoid">
                <div>
                  <div className="h-12 border-b border-dashed border-slate-400 mx-12"></div>
                  <p className="mt-2 font-medium text-slate-900">({currentUser.fullName})</p>
                  <p className="text-slate-500">{currentUser.position || 'เจ้าหน้าที่ผู้จัดทำรายงาน'}</p>
                  <p className="text-slate-400 mt-1">วันที่ ....../....../......</p>
                </div>
                <div>
                  <div className="h-12 border-b border-dashed border-slate-400 mx-12"></div>
                  <p className="mt-2 font-medium text-slate-900">(.........................................................)</p>
                  <p className="text-slate-500">หัวหน้าฝ่าย / ผู้มีอำนาจตรวจสอบรับรอง</p>
                  <p className="text-slate-400 mt-1">วันที่ ....../....../......</p>
                </div>
              </div>
            </div>
          ) : (
            /* ========================================================================= */
            /* MODE 2: SINGLE OFFICIAL RECORD PRINT */
            /* ========================================================================= */
            record && (
              <div className="space-y-6">
                {/* Header */}
                <div className="border-b-2 border-slate-900 pb-4">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-slate-900 text-white rounded-lg flex items-center justify-center font-bold text-xl tracking-tighter">
                        EO
                      </div>
                      <div>
                        <h1 className="text-xl font-bold tracking-tight text-slate-900">
                          ระบบบริหารงานสำนักงานอิเล็กทรอนิกส์ E-OFFICE
                        </h1>
                        <p className="text-xs text-slate-500">
                          กลุ่มงานบริหารทั่วไปและสารสนเทศภาครัฐ
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="inline-block px-3 py-1 bg-slate-100 border border-slate-300 text-slate-900 text-xs font-mono font-bold rounded">
                        {record.recordNumber}
                      </span>
                      <p className="text-xs text-slate-600 mt-1">วันที่จัดทำ: {record.date}</p>
                    </div>
                  </div>

                  <div className="mt-5 text-center">
                    <h2 className="text-lg font-bold text-slate-900 tracking-wide underline decoration-slate-400 underline-offset-4">
                      {getDocTypeName(record)}
                    </h2>
                  </div>
                </div>

                {/* Primary Meta Grid */}
                <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                  <div>
                    <span className="text-slate-500 block mb-0.5">หัวข้อ / รายการ:</span>
                    <span className="font-bold text-slate-900 text-sm">{record.title}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-0.5">หมวดหมู่รายการ:</span>
                    <span className="font-semibold text-slate-800">{record.category || 'ทั่วไป'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-0.5">สถานะเอกสาร:</span>
                    <span className="inline-flex items-center font-semibold text-slate-900">
                      {record.status === 'completed' && '✓ เสร็จสมบูรณ์ / ดำเนินการเรียบร้อย'}
                      {record.status === 'pending' && '⏳ รอดำเนินการ / รอชำระ'}
                      {record.status === 'approved' && '✓ อนุมัติเรียบร้อยแล้ว'}
                      {record.status === 'rejected' && '✗ ไม่อนุมัติ'}
                      {record.status === 'cancelled' && '⊘ ยกเลิกรายการ'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-0.5">ผู้จัดทำรายการ:</span>
                    <span className="font-semibold text-slate-800">{record.createdByName}</span>
                  </div>
                </div>

                {/* ======================= FUNCTION 1: DOCUMENT ======================= */}
                {record.type === 'document' && (
                  <div className="border border-slate-200 rounded-xl p-5 space-y-4">
                    <h3 className="font-bold text-xs uppercase tracking-wider text-indigo-900 border-b pb-2 flex items-center space-x-1.5">
                      <FileText className="w-4 h-4 text-indigo-600" />
                      <span>ข้อมูลงานสารบรรณและหนังสือราชการ</span>
                    </h3>
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <strong className="text-slate-600">เลขที่หนังสือ:</strong>{' '}
                        <span className="font-mono font-semibold text-slate-900">
                          {record.documentNumber || '-'}
                        </span>
                      </div>
                      <div>
                        <strong className="text-slate-600">ประเภทหนังสือ:</strong>{' '}
                        <span className="font-semibold text-slate-900">
                          {record.documentType || 'บันทึกข้อความ'}
                        </span>
                      </div>
                      <div>
                        <strong className="text-slate-600">จาก (ผู้ส่ง/หน่วยงานส่ง):</strong>{' '}
                        <span className="font-medium text-slate-800">{record.sender || '-'}</span>
                      </div>
                      <div>
                        <strong className="text-slate-600">ถึง (ผู้รับ/หน่วยงานรับ):</strong>{' '}
                        <span className="font-medium text-slate-800">{record.receiver || '-'}</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* ======================= FUNCTION 2 & 3: INCOME / EXPENSE ======================= */}
                {(record.type === 'income' || record.type === 'expense') && (
                  <div className="border border-slate-200 rounded-xl p-5 space-y-4">
                    <h3 className="font-bold text-xs uppercase tracking-wider text-slate-700 border-b pb-2">
                      {record.type === 'income' ? 'ข้อมูลการรับเงินและใบเสร็จ' : 'ข้อมูลการจ่ายเงินและหลักฐาน'}
                    </h3>
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <strong className="text-slate-600">วิธีการชำระเงิน:</strong>{' '}
                        <span className="font-medium text-slate-900">{record.paymentMethod || 'โอนผ่านธนาคาร'}</span>
                      </div>
                      <div>
                        <strong className="text-slate-600">เลขที่ใบเสร็จ/อ้างอิง:</strong>{' '}
                        <span className="font-mono font-semibold text-slate-900">
                          {record.referenceNumber || '-'}
                        </span>
                      </div>
                    </div>

                    {/* Amount & Thai Baht Text */}
                    <div className="pt-3 border-t border-slate-200 bg-slate-50/70 p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                      <div>
                        <span className="text-xs text-slate-500 block">จำนวนเงินตัวอักษร:</span>
                        <span className="text-sm font-semibold text-slate-800">
                          ({thaiBahtText(record.amount)})
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-slate-500 block">จำนวนเงินสุทธิ:</span>
                        <span className={`text-2xl font-bold font-mono ${record.type === 'income' ? 'text-emerald-700' : 'text-rose-700'}`}>
                          ฿{(record.amount || 0).toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* ======================= FUNCTION 4: LOAN ======================= */}
                {record.type === 'loan' && (
                  <div className="border border-slate-200 rounded-xl p-5 space-y-4">
                    <h3 className="font-bold text-xs uppercase tracking-wider text-amber-900 border-b pb-2">
                      รายละเอียดสัญญาสินเชื่อและเงื่อนไขการชำระเงิน
                    </h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                      <div>
                        <strong className="text-slate-600">ชื่อผู้กู้ยืม:</strong>{' '}
                        <span className="font-bold text-slate-900 block mt-0.5">{record.borrowerName || '-'}</span>
                      </div>
                      <div>
                        <strong className="text-slate-600">จำนวนงวดที่ต้องชำระ:</strong>{' '}
                        <span className="font-bold text-indigo-900 block mt-0.5">
                          {record.installmentCount || record.loanTermMonths || '-'} งวด
                        </span>
                      </div>
                      <div>
                        <strong className="text-slate-600">ระยะเวลาผ่อนชำระ:</strong>{' '}
                        <span className="font-medium text-slate-800 block mt-0.5">
                          {record.loanTermMonths || '-'} เดือน
                        </span>
                      </div>
                      <div>
                        <strong className="text-slate-600">ค่างวดต่อเดือน:</strong>{' '}
                        <span className="font-semibold text-slate-900 block mt-0.5">
                          ฿{(record.monthlyInstallment || 0).toLocaleString()}
                        </span>
                      </div>
                      <div>
                        <strong className="text-slate-600">วันที่ต้องชำระงวดถัดไป:</strong>{' '}
                        <span className="font-semibold text-slate-900 block mt-0.5">
                          {record.dueDate || '-'}
                        </span>
                      </div>
                      <div>
                        <strong className="text-slate-600">ยอดชำระสะสมแล้ว:</strong>{' '}
                        <span className="font-semibold text-emerald-700 block mt-0.5">
                          ฿{(record.totalPaid || 0).toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Amount & Thai Baht Text */}
                    <div className="pt-3 border-t border-slate-200 bg-amber-50/50 p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                      <div>
                        <span className="text-xs text-slate-600 block">วงเงินสินเชื่อตัวอักษร:</span>
                        <span className="text-sm font-bold text-slate-900">
                          ({thaiBahtText(record.amount)})
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-slate-600 block">วงเงินสินเชื่อรวม:</span>
                        <span className="text-2xl font-bold font-mono text-amber-700">
                          ฿{(record.amount || 0).toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                    </div>

                    {/* Installment Schedule Table Breakdown */}
                    <div className="pt-2">
                      <span className="text-xs font-bold text-slate-700 block mb-2">
                        ตารางสรุปงวดการชำระเงิน (Installment Schedule):
                      </span>
                      <div className="border border-slate-200 rounded-lg overflow-hidden">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-100 text-slate-700">
                            <tr>
                              <th className="py-2 px-3 text-center w-16">งวดที่</th>
                              <th className="py-2 px-3">ประมาณการวันครบกำหนด</th>
                              <th className="py-2 px-3 text-right">ยอดชำระต่องวด</th>
                              <th className="py-2 px-3 text-center w-28">ลายมือชื่อผู้รับเงิน</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200">
                            {Array.from({ length: Math.min(record.installmentCount || record.loanTermMonths || 6, 12) }).map((_, i) => (
                              <tr key={i} className="hover:bg-slate-50">
                                <td className="py-1.5 px-3 text-center font-mono font-medium text-slate-700">{i + 1}</td>
                                <td className="py-1.5 px-3 text-slate-600">
                                  {record.dueDate ? `ทุกวันที่ ${record.dueDate.split('-')[2] || '25'} ของเดือน` : `งวดประจำเดือน ${i + 1}`}
                                </td>
                                <td className="py-1.5 px-3 text-right font-mono font-medium text-slate-800">
                                  ฿{(record.monthlyInstallment || (record.amount ? Math.round(record.amount / (record.installmentCount || 12)) : 0)).toLocaleString()}
                                </td>
                                <td className="py-1.5 px-3 text-center text-slate-300">...............</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}

                {/* ======================= FUNCTION 5: WITHDRAWAL ======================= */}
                {record.type === 'withdrawal' && (
                  <div className="border border-slate-200 rounded-xl p-5 space-y-4">
                    <h3 className="font-bold text-xs uppercase tracking-wider text-purple-900 border-b pb-2">
                      รายละเอียดการขออนุมัติเบิกเงินและสวัสดิการ
                    </h3>
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <strong className="text-slate-600">ผู้ขอเบิกเงิน:</strong>{' '}
                        <span className="font-bold text-slate-900">{record.applicantName || record.createdByName}</span>
                      </div>
                      <div>
                        <strong className="text-slate-600">สถานะการอนุมัติ:</strong>{' '}
                        <span className={`font-bold ${record.status === 'approved' ? 'text-emerald-700' : 'text-amber-700'}`}>
                          {record.status === 'approved' ? 'อนุมัติเรียบร้อยแล้ว' : 'รอดำเนินการอนุมัติ'}
                        </span>
                      </div>
                      <div>
                        <strong className="text-slate-600">ผู้อนุมัติ:</strong>{' '}
                        <span className="font-medium text-slate-800">{record.approverName || 'รอผู้มีอำนาจลงนาม'}</span>
                      </div>
                      <div>
                        <strong className="text-slate-600">วันที่อนุมัติ:</strong>{' '}
                        <span className="font-medium text-slate-800">{record.approvalDate || '-'}</span>
                      </div>
                      {record.approvalNote && (
                        <div className="col-span-2">
                          <strong className="text-slate-600">ความเห็น/บันทึกผู้อนุมัติ:</strong>{' '}
                          <span className="text-slate-800 italic">{record.approvalNote}</span>
                        </div>
                      )}
                    </div>

                    {/* Amount & Thai Baht Text */}
                    <div className="pt-3 border-t border-slate-200 bg-purple-50/50 p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                      <div>
                        <span className="text-xs text-slate-600 block">จำนวนเงินขอเบิกตัวอักษร:</span>
                        <span className="text-sm font-bold text-slate-900">
                          ({thaiBahtText(record.amount)})
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-slate-600 block">ยอดเงินที่ขอเบิก:</span>
                        <span className="text-2xl font-bold font-mono text-purple-700">
                          ฿{(record.amount || 0).toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Description Box */}
                {record.description && (
                  <div className="p-4 bg-slate-50/80 rounded-xl border border-slate-200 text-xs">
                    <span className="font-bold text-slate-600 block mb-1">รายละเอียด / หมายเหตุเพิ่มเติม:</span>
                    <p className="text-slate-800 whitespace-pre-wrap leading-relaxed">{record.description}</p>
                  </div>
                )}

                {/* Attachments List */}
                {record.attachments && record.attachments.length > 0 && (
                  <div className="text-xs text-slate-500 border-t border-slate-100 pt-2">
                    <span className="font-medium text-slate-700">เอกสารประกอบแนบ: </span>
                    {record.attachments.map(a => a.name).join(', ')}
                  </div>
                )}

                {/* Official Signatures (3 Columns for Withdrawal / 2 Columns for others) */}
                <div className="mt-10 pt-8 border-t border-slate-300 print-break-inside-avoid">
                  {record.type === 'withdrawal' ? (
                    <div className="grid grid-cols-3 gap-4 text-center text-xs">
                      <div>
                        <div className="h-12 border-b border-dashed border-slate-400 mx-4"></div>
                        <p className="mt-2 font-medium text-slate-900">({record.applicantName || record.createdByName})</p>
                        <p className="text-slate-500">ผู้ขอเบิกเงิน</p>
                        <p className="text-slate-400 mt-1">วันที่ ....../....../......</p>
                      </div>
                      <div>
                        <div className="h-12 border-b border-dashed border-slate-400 mx-4"></div>
                        <p className="mt-2 font-medium text-slate-900">(..........................................)</p>
                        <p className="text-slate-500">เจ้าหน้าที่ตรวจสอบการเงิน</p>
                        <p className="text-slate-400 mt-1">วันที่ ....../....../......</p>
                      </div>
                      <div>
                        <div className="h-12 border-b border-dashed border-slate-400 mx-4"></div>
                        <p className="mt-2 font-medium text-slate-900">({record.approverName || '..........................................'})</p>
                        <p className="text-slate-500">ผู้มีอำนาจอนุมัติจ่าย</p>
                        <p className="text-slate-400 mt-1">วันที่ ....../....../......</p>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-8 text-center text-xs">
                      <div>
                        <div className="h-12 border-b border-dashed border-slate-400 mx-10"></div>
                        <p className="mt-2 font-medium text-slate-900">({record.borrowerName || record.createdByName})</p>
                        <p className="text-slate-500">
                          {record.type === 'loan' ? 'ผู้กู้ยืมเงิน' : record.type === 'income' ? 'ผู้รับเงิน' : 'ผู้จัดทำ / ผู้รายงาน'}
                        </p>
                        <p className="text-slate-400 mt-1">วันที่ ....../....../......</p>
                      </div>
                      <div>
                        <div className="h-12 border-b border-dashed border-slate-400 mx-10"></div>
                        <p className="mt-2 font-medium text-slate-900">(.........................................................)</p>
                        <p className="text-slate-500">
                          {record.type === 'loan' ? 'ผู้มีอำนาจอนุมัติสินเชื่อ' : 'ผู้มีอำนาจลงนาม / หัวหน้างาน'}
                        </p>
                        <p className="text-slate-400 mt-1">วันที่ ....../....../......</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};
