import React from 'react';
import { AppUser, GoogleSheetConfig } from '../types';
import { 
  Building2, 
  User as UserIcon, 
  LogOut, 
  Menu, 
  FileSpreadsheet, 
  Shield, 
  ExternalLink,
  Smartphone,
  ChevronDown
} from 'lucide-react';

interface NavbarProps {
  currentUser: AppUser;
  onLogout: () => void;
  onOpenSheetModal: () => void;
  sheetConfig: GoogleSheetConfig;
  onToggleMobileMenu: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onLogout,
  onOpenSheetModal,
  sheetConfig,
  onToggleMobileMenu,
}) => {
  const isAdmin = currentUser.role === 'admin';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Title */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onToggleMobileMenu}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 transition"
              aria-label="เปิดเมนู"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="flex items-center space-x-2.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-lg text-slate-900 tracking-tight">E-OFFICE</span>
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                    isAdmin ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-blue-100 text-blue-800'
                  }`}>
                    {isAdmin ? 'ADMIN' : 'USER'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 hidden sm:block">
                  ระบบบริหารจัดการสำนักงานอิเล็กทรอนิกส์
                </p>
              </div>
            </div>
          </div>

          {/* Right Action Bar */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Google Sheet Direct Quick Link & Sync Button (Only for Admin) */}
            {isAdmin && (
              <div className="hidden sm:flex items-center space-x-2">
                <button
                  onClick={onOpenSheetModal}
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-300 hover:bg-emerald-100 text-emerald-800 text-xs font-medium transition"
                  title="คลิกเพื่อตั้งค่าและดูวิธีเปิดระบบซิงค์ Google Sheet"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  <span className="font-semibold">Google Sheet</span>
                  <span className="hidden md:inline text-[11px] text-emerald-600 font-mono">
                    ({sheetConfig.sheetId.slice(0, 6)}...)
                  </span>
                </button>
                <a
                  href={sheetConfig.sheetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 text-slate-400 hover:text-emerald-700 rounded-lg hover:bg-slate-100 transition"
                  title="เปิด Google Sheet ในแท็บใหม่"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            )}

            {/* Current User Badge & Logout */}
            <div className="flex items-center space-x-2 pl-2 border-l border-slate-200">
              <div className="flex items-center space-x-2 text-left">
                <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs">
                  {currentUser.fullName ? currentUser.fullName.charAt(0) : 'U'}
                </div>
                <div className="hidden md:block">
                  <div className="text-xs font-semibold text-slate-800 leading-tight">
                    {currentUser.fullName}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    @{currentUser.username} ({currentUser.department || 'สำนักงาน'})
                  </div>
                </div>
              </div>

              <button
                onClick={onLogout}
                className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                title="ออกจากระบบ"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
