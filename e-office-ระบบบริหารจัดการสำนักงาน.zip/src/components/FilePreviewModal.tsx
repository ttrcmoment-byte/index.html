import React from 'react';
import { FileAttachment } from '../types';
import { X, Download, FileText, ExternalLink, Image as ImageIcon } from 'lucide-react';

interface FilePreviewModalProps {
  attachment: FileAttachment | null;
  onClose: () => void;
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({ attachment, onClose }) => {
  if (!attachment) return null;

  const isImage = attachment.type.startsWith('image/') || attachment.name.match(/\.(jpeg|jpg|png|gif|webp)$/i);
  const isPdf = attachment.type === 'application/pdf' || attachment.name.endsWith('.pdf');

  const handleDownload = () => {
    if (attachment.dataUrl) {
      const link = document.createElement('a');
      link.href = attachment.dataUrl;
      link.download = attachment.name;
      link.click();
    } else {
      alert('จำลองการดาวน์โหลดไฟล์: ' + attachment.name);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              {isImage ? <ImageIcon className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-semibold text-slate-800 truncate max-w-md" title={attachment.name}>
                {attachment.name}
              </h3>
              <p className="text-xs text-slate-500">
                ขนาด: {(attachment.size / 1024).toFixed(1)} KB • อัปโหลดเมื่อ: {new Date(attachment.uploadedAt).toLocaleString('th-TH')}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleDownload}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition"
              title="ดาวน์โหลดไฟล์"
            >
              <Download className="w-4 h-4" />
              <span>ดาวน์โหลด</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition"
              aria-label="ปิด"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Viewer */}
        <div className="p-6 overflow-y-auto flex-1 flex flex-col items-center justify-center bg-slate-100 min-h-[350px]">
          {isImage && attachment.dataUrl ? (
            <img
              src={attachment.dataUrl}
              alt={attachment.name}
              className="max-h-[60vh] max-w-full rounded-lg shadow-xs object-contain"
            />
          ) : isPdf ? (
            <div className="w-full h-[60vh] flex flex-col items-center justify-center bg-white rounded-xl shadow-xs border border-slate-200 p-8 text-center">
              <div className="w-16 h-16 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mb-4">
                <FileText className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-semibold text-slate-800 mb-1">{attachment.name}</h4>
              <p className="text-sm text-slate-500 mb-4">เอกสาร PDF พร้อมสำหรับเปิดอ่านและพิมพ์</p>
              <div className="flex space-x-3">
                <button
                  onClick={handleDownload}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-sm font-medium inline-flex items-center space-x-2 transition"
                >
                  <Download className="w-4 h-4" />
                  <span>บันทึกไฟล์ PDF</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center p-8 bg-white rounded-xl shadow-xs border border-slate-200 w-full">
              <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-semibold text-slate-800 mb-1">{attachment.name}</h4>
              <p className="text-sm text-slate-500 mb-6">ไฟล์แนบระบบ E-OFFICE</p>
              <button
                onClick={handleDownload}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium inline-flex items-center space-x-2 transition"
              >
                <Download className="w-4 h-4" />
                <span>ดาวน์โหลดไฟล์</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
