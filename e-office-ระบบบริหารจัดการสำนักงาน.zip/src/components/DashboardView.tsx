import React, { useState, useMemo } from 'react';
import { GeneralRecord, AppUser, GoogleSheetConfig } from '../types';
import { exportRecordsToCSV, exportRecordsToExcel } from '../utils/googleSheets';
import { 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Landmark, 
  FileText, 
  ArrowUpRight, 
  Search, 
  Download, 
  Printer, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  FileSpreadsheet,
  RefreshCw,
  ExternalLink,
  Eye,
  SlidersHorizontal
} from 'lucide-react';

interface DashboardViewProps {
  records: GeneralRecord[];
  currentUser: AppUser;
  sheetConfig: GoogleSheetConfig;
  onOpenSheetModal: () => void;
  onViewFile: (record: GeneralRecord) => void;
  onPrintRecord: (record: GeneralRecord) => void;
  onTriggerSync: () => Promise<void>;
  isSyncing: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  records,
  currentUser,
  sheetConfig,
  onOpenSheetModal,
  onViewFile,
  onPrintRecord,
  onTriggerSync,
  isSyncing,
}) => {
  const isAdmin = currentUser.role === 'admin';
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState<'all' | 'today' | 'this_month' | 'this_year'>('all');

  // Filter records based on role and active search/filters
  const userFilteredRecords = useMemo(() => {
    // If not admin, normal user sees only records they created
    let list = isAdmin ? records : records.filter(r => r.createdByUserId === currentUser.id);

    // Type filter
    if (selectedTypeFilter !== 'all') {
      list = list.filter(r => r.type === selectedTypeFilter);
    }

    // Date range filter
    if (dateRange !== 'all') {
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth(); // 0-indexed
      const todayStr = now.toISOString().split('T')[0];

      list = list.filter(r => {
        if (!r.date) return false;
        const recDate = new Date(r.date);
        if (dateRange === 'today') {
          return r.date === todayStr;
        }
        if (dateRange === 'this_month') {
          return recDate.getFullYear() === currentYear && recDate.getMonth() === currentMonth;
        }
        if (dateRange === 'this_year') {
          return recDate.getFullYear() === currentYear;
        }
        return true;
      });
    }

    // Search term (searches title, category, record number, person, document number)
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      list = list.filter(r => 
        r.title.toLowerCase().includes(term) ||
        (r.category && r.category.toLowerCase().includes(term)) ||
        (r.recordNumber && r.recordNumber.toLowerCase().includes(term)) ||
        (r.documentNumber && r.documentNumber.toLowerCase().includes(term)) ||
        (r.borrowerName && r.borrowerName.toLowerCase().includes(term)) ||
        (r.applicantName && r.applicantName.toLowerCase().includes(term)) ||
        (r.createdByName && r.createdByName.toLowerCase().includes(term))
      );
    }

    return list;
  }, [records, isAdmin, currentUser.id, selectedTypeFilter, dateRange, searchTerm]);

  // Financial and Operational Summaries
  const stats = useMemo(() => {
    const relevantRecords = isAdmin ? records : records.filter(r => r.createdByUserId === currentUser.id);

    const totalIncome = relevantRecords
      .filter(r => r.type === 'income')
      .reduce((sum, r) => sum + (r.amount || 0), 0);

    const totalExpense = relevantRecords
      .filter(r => r.type === 'expense')
      .reduce((sum, r) => sum + (r.amount || 0), 0);

    const netBalance = totalIncome - totalExpense;

    const totalLoans = relevantRecords
      .filter(r => r.type === 'loan')
      .reduce((sum, r) => sum + (r.amount || 0), 0);

    const loanPaid = relevantRecords
      .filter(r => r.type === 'loan')
      .reduce((sum, r) => sum + (r.totalPaid || 0), 0);

    const totalWithdrawal = relevantRecords
      .filter(r => r.type === 'withdrawal')
      .reduce((sum, r) => sum + (r.amount || 0), 0);

    const pendingWithdrawal = relevantRecords
      .filter(r => r.type === 'withdrawal' && r.status === 'pending')
      .reduce((sum, r) => sum + (r.amount || 0), 0);

    const totalDocs = relevantRecords.filter(r => r.type === 'document').length;

    return {
      totalIncome,
      totalExpense,
      netBalance,
      totalLoans,
      loanPaid,
      loanOutstanding: totalLoans - loanPaid,
      totalWithdrawal,
      pendingWithdrawal,
      totalDocs,
      totalCount: relevantRecords.length
    };
  }, [records, isAdmin, currentUser.id]);

  // Export handlers
  const handleExportCSV = () => {
    exportRecordsToCSV(userFilteredRecords, `eoffice_${isAdmin ? 'admin' : 'user'}_records.csv`);
  };

  const handleExportExcel = () => {
    exportRecordsToExcel(userFilteredRecords, `eoffice_${isAdmin ? 'admin' : 'user'}_records.xls`);
  };

  const handlePrintDashboard = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner with Google Sheet sync reminder & status */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {isAdmin ? 'แดชบอร์ดผู้ดูแลระบบ (Admin)' : 'แดชบอร์ดผู้ใช้งาน (User)'}
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
              E-OFFICE
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {isAdmin 
              ? 'สรุปภาพรวมเอกสาร การเงิน รายรับ-รายจ่าย สินเชื่อ และสถานะเชื่อมโยง Google Sheet'
              : 'สรุปภาพรวมและรายการของฉัน พร้อมระบบค้นหาและส่งออกข้อมูล (Export)'}
          </p>
        </div>

        {/* Action Buttons: Export & (Sync for Admin) */}
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Export Dropdown / Buttons */}
          <div className="flex items-center space-x-1.5 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={handleExportExcel}
              className="px-3 py-1.5 bg-white hover:bg-emerald-50 text-emerald-700 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition shadow-2xs border border-slate-200"
              title="ส่งออกไฟล์ Excel"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Excel</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 bg-white hover:bg-blue-50 text-blue-700 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition shadow-2xs border border-slate-200"
              title="ส่งออกไฟล์ CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={handlePrintDashboard}
              className="px-3 py-1.5 bg-white hover:bg-slate-200/60 text-slate-700 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition shadow-2xs border border-slate-200"
              title="พิมพ์รายงานสรุป"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>พิมพ์</span>
            </button>
          </div>

          {/* Admin Sync Action */}
          {isAdmin && (
            <div className="flex items-center space-x-1.5">
              <button
                onClick={onTriggerSync}
                disabled={isSyncing}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl flex items-center space-x-1.5 transition shadow-xs"
                title="ซิงค์ข้อมูลกับ Google Sheet"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'กำลังซิงค์...' : 'ซิงค์ Google Sheet'}</span>
              </button>
              <button
                onClick={onOpenSheetModal}
                className="p-2 border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl transition"
                title="วิธีเปิดระบบบันทึกและซิงค์ข้อมูล Google Sheet"
              >
                <FileSpreadsheet className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Linked Google Sheet Status Banner for Admin */}
      {isAdmin && (
        <div className="bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-blue-500/10 border border-emerald-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-600 text-white rounded-xl shadow-xs shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-slate-800 flex items-center space-x-2">
                <span>เชื่อมโยง Google Sheet อัตโนมัติ:</span>
                <span className="font-mono text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  {sheetConfig.sheetId}
                </span>
              </div>
              <p className="text-slate-600 mt-0.5">
                {sheetConfig.webhookUrl 
                  ? 'ระบบบันทึกตรงสู่ Google Sheet ผ่าน Webhook แบบ Real-time' 
                  : 'พร้อมใช้งาน • คลิก "วิธีเปิดระบบและซิงค์" เพื่อนำ URL Webhook มาวางเชื่อมต่อ'}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2 self-end sm:self-center shrink-0">
            <button
              onClick={onOpenSheetModal}
              className="text-emerald-700 hover:text-emerald-900 font-semibold underline underline-offset-2 flex items-center space-x-1"
            >
              <span>วิธีเปิดระบบและคู่มือติดตั้ง</span>
            </button>
            <a
              href={sheetConfig.sheetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 bg-white border border-emerald-300 text-emerald-800 rounded-lg hover:bg-emerald-50 flex items-center space-x-1 font-medium transition"
            >
              <span>เปิด Sheet</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      )}

      {/* Overview Cards (Metrics) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Income Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-emerald-300 transition group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">บันทึกรายรับรวม</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl group-hover:scale-110 transition">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900">
              ฿{stats.totalIncome.toLocaleString('th-TH', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-[11px] text-emerald-600 mt-1 font-medium flex items-center space-x-1">
              <span>เงินงบประมาณ & รายรับบริการ</span>
            </p>
          </div>
        </div>

        {/* Expense Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-rose-300 transition group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">บันทึกรายจ่ายรวม</span>
            <div className="p-2 bg-rose-50 text-rose-600 rounded-xl group-hover:scale-110 transition">
              <TrendingDown className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900">
              ฿{stats.totalExpense.toLocaleString('th-TH', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-[11px] text-rose-600 mt-1 font-medium flex items-center space-x-1">
              <span>ค่าวัสดุ, สาธารณูปโภค & ค่าใช้จ่าย</span>
            </p>
          </div>
        </div>

        {/* Net Balance Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-blue-300 transition group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">ยอดคงเหลือสุทธิ</span>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl group-hover:scale-110 transition">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className={`text-2xl font-bold ${stats.netBalance >= 0 ? 'text-blue-700' : 'text-rose-600'}`}>
              ฿{stats.netBalance.toLocaleString('th-TH', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              รายรับหักลบรายจ่ายสุทธิ
            </p>
          </div>
        </div>

        {/* Loans / Credit Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-amber-300 transition group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">สินเชื่อสวัสดิการ</span>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl group-hover:scale-110 transition">
              <Landmark className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900">
              ฿{stats.totalLoans.toLocaleString('th-TH', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-[11px] text-amber-700 mt-1">
              คงค้างชำระ: ฿{stats.loanOutstanding.toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      {/* Secondary Stats Row (Withdrawal & Documents) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex items-center space-x-3">
          <div className="p-3 bg-purple-50 text-purple-600 rounded-xl">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-500 font-medium">เอกสารในระบบ</div>
            <div className="text-lg font-bold text-slate-800">{stats.totalDocs} ฉบับ</div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex items-center space-x-3">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <ArrowUpRight className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-500 font-medium">ยอดขอเบิกเงินทั้งหมด</div>
            <div className="text-lg font-bold text-slate-800">
              ฿{stats.totalWithdrawal.toLocaleString()}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex items-center space-x-3">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-500 font-medium">ยอดเบิกเงินรออนุมัติ</div>
            <div className="text-lg font-bold text-amber-600">
              ฿{stats.pendingWithdrawal.toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filter Toolbar (ค้นหา Expost) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ค้นหารายการ, เลขที่หนังสือ, ชื่อผู้กู้, ผู้ขอเบิก, หมวดหมู่..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 bg-slate-200 px-1.5 py-0.5 rounded-full"
              >
                ล้าง
              </button>
            )}
          </div>

          {/* Quick Filters */}
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={selectedTypeFilter}
              onChange={(e) => setSelectedTypeFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">ทุกประเภทรายการ</option>
              <option value="document">เอกสาร</option>
              <option value="income">บันทึกรายรับ</option>
              <option value="expense">บันทึกรายจ่าย</option>
              <option value="loan">สินเชื่อ</option>
              <option value="withdrawal">เบิกเงิน</option>
            </select>

            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value as any)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">ทุกช่วงเวลา</option>
              <option value="today">วันนี้</option>
              <option value="this_month">เดือนนี้</option>
              <option value="this_year">ปีนี้</option>
            </select>
          </div>
        </div>

        {/* Results Count & Export Banner */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-500">
          <div>
            ผลการค้นหา: <span className="font-semibold text-slate-800">{userFilteredRecords.length}</span> รายการ
            {searchTerm && <span> (คำค้น: "{searchTerm}")</span>}
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleExportExcel}
              className="text-emerald-700 hover:text-emerald-900 font-medium flex items-center space-x-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Expost Excel</span>
            </button>
            <span>•</span>
            <button
              onClick={handleExportCSV}
              className="text-blue-700 hover:text-blue-900 font-medium flex items-center space-x-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Expost CSV</span>
            </button>
          </div>
        </div>

        {/* Records Table / List */}
        <div className="overflow-x-auto -mx-5 px-5">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-medium bg-slate-50/70">
                <th className="py-3 px-3">รหัส/ประเภท</th>
                <th className="py-3 px-3">วันที่</th>
                <th className="py-3 px-3">หัวข้อรายการ</th>
                <th className="py-3 px-3">หมวดหมู่</th>
                <th className="py-3 px-3 text-right">จำนวนเงิน (บาท)</th>
                <th className="py-3 px-3 text-center">สถานะ</th>
                <th className="py-3 px-3 text-right">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {userFilteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    ไม่พบข้อมูลที่ตรงกับเงื่อนไขการค้นหา
                  </td>
                </tr>
              ) : (
                userFilteredRecords.map((r) => {
                  const typeLabel = {
                    document: 'เอกสาร',
                    income: 'รายรับ',
                    expense: 'รายจ่าย',
                    loan: 'สินเชื่อ',
                    withdrawal: 'เบิกเงิน',
                  }[r.type] || r.type;

                  const typeBadgeClass = {
                    document: 'bg-purple-50 text-purple-700 border-purple-200',
                    income: 'bg-emerald-50 text-emerald-700 border-emerald-200',
                    expense: 'bg-rose-50 text-rose-700 border-rose-200',
                    loan: 'bg-amber-50 text-amber-700 border-amber-200',
                    withdrawal: 'bg-indigo-50 text-indigo-700 border-indigo-200',
                  }[r.type];

                  return (
                    <tr key={r.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3 px-3">
                        <span className="font-mono font-medium text-slate-900 block">
                          {r.recordNumber}
                        </span>
                        <span className={`inline-block text-[10px] px-1.5 py-0.5 rounded border ${typeBadgeClass} mt-0.5 font-medium`}>
                          {typeLabel}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                        {r.date}
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-medium text-slate-900 max-w-xs truncate" title={r.title}>
                          {r.title}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">
                          {r.type === 'document' && `เลขที่: ${r.documentNumber || '-'} (${r.documentType})`}
                          {r.type === 'loan' && `ผู้กู้: ${r.borrowerName || '-'} (งวดถัดไป: ${r.dueDate})`}
                          {r.type === 'withdrawal' && `ผู้ขอเบิก: ${r.applicantName || r.createdByName}`}
                          {(r.type === 'income' || r.type === 'expense') && `วิธี: ${r.paymentMethod || 'โอน'}`}
                        </div>
                      </td>
                      <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                        <span className="bg-slate-100 px-2 py-0.5 rounded-full text-xs">
                          {r.category}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-semibold whitespace-nowrap">
                        {r.amount != null ? (
                          <span className={r.type === 'income' ? 'text-emerald-600' : r.type === 'expense' ? 'text-rose-600' : 'text-slate-800'}>
                            {r.type === 'income' ? '+' : r.type === 'expense' ? '-' : ''}
                            ฿{r.amount.toLocaleString()}
                          </span>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[11px] font-medium ${
                          r.status === 'completed' || r.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : r.status === 'pending'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {r.status === 'completed' && 'เสร็จสมบูรณ์'}
                          {r.status === 'approved' && 'อนุมัติแล้ว'}
                          {r.status === 'pending' && 'รอดำเนินการ'}
                          {r.status === 'cancelled' && 'ยกเลิก'}
                          {r.status === 'rejected' && 'ไม่อนุมัติ'}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end space-x-1.5">
                          {r.attachments && r.attachments.length > 0 && (
                            <button
                              onClick={() => onViewFile(r)}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                              title="ดูไฟล์แนบ"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => onPrintRecord(r)}
                            className="p-1.5 text-slate-600 hover:bg-slate-100 rounded-lg transition"
                            title="พิมพ์รายการนี้"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
