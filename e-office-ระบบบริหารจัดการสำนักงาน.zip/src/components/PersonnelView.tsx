import React, { useState } from 'react';
import { AppUser } from '../types';
import { 
  UserCheck, 
  Search, 
  Plus, 
  Phone, 
  Mail, 
  Building, 
  Briefcase, 
  Calendar, 
  Edit3, 
  Printer,
  Shield,
  CheckCircle2
} from 'lucide-react';

interface PersonnelViewProps {
  users: AppUser[];
  onSaveUser: (user: AppUser) => void;
  currentUser: AppUser;
}

export const PersonnelView: React.FC<PersonnelViewProps> = ({
  users,
  onSaveUser,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [selectedUserForDetail, setSelectedUserForDetail] = useState<AppUser | null>(null);

  const departments = Array.from(new Set(users.map((u) => u.department).filter(Boolean)));

  const filtered = users.filter((u) => {
    const matchesSearch =
      u.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.phone.includes(searchTerm) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = departmentFilter === 'all' || u.department === departmentFilter;
    return matchesSearch && matchesDept;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center space-x-2">
            <UserCheck className="w-6 h-6 text-blue-600" />
            <span>งานบุคคล (Personnel Management)</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            ข้อมูลบุคลากร ทะเบียนประวัติ ตำแหน่ง สังกัด และช่องทางการติดต่อ
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-500">
          <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full font-bold">
            บุคลากรทั้งหมด {users.length} ท่าน
          </span>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ค้นหาชื่อบุคลากร, ตำแหน่ง, ฝ่ายงาน, เบอร์โทร..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="w-full sm:w-auto">
          <select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">ทุกฝ่าย/แผนก</option>
            {departments.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Personnel Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((user) => (
          <div
            key={user.id}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition flex flex-col justify-between"
          >
            <div>
              {/* Header with Avatar & Role */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
                    {user.fullName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-base leading-tight">
                      {user.fullName}
                    </h3>
                    <p className="text-xs text-blue-600 font-medium mt-0.5">
                      {user.position || 'เจ้าหน้าที่'}
                    </p>
                  </div>
                </div>

                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  user.role === 'admin'
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-slate-100 text-slate-700'
                }`}>
                  {user.role.toUpperCase()}
                </span>
              </div>

              {/* Department & Contact Details */}
              <div className="space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-3">
                <div className="flex items-center space-x-2">
                  <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{user.department || 'สำนักบริหารกลาง'}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{user.phone || '-'}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{user.email || '-'}</span>
                </div>
                <div className="flex items-center space-x-2 text-slate-400">
                  <Calendar className="w-3.5 h-3.5 shrink-0" />
                  <span>วันที่เริ่มงาน: {user.createdAt ? new Date(user.createdAt).toLocaleDateString('th-TH') : '-'}</span>
                </div>
              </div>
            </div>

            {/* Footer Action */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="flex items-center space-x-1 text-emerald-600 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>สถานะ: ปฏิบัติงานปกติ</span>
              </span>
              <button
                onClick={() => setSelectedUserForDetail(user)}
                className="text-blue-600 hover:text-blue-800 font-semibold"
              >
                ดูรายละเอียด
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* User Detail Modal */}
      {selectedUserForDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-slate-800 space-y-4">
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold text-2xl mx-auto shadow-md">
                {selectedUserForDetail.fullName.charAt(0)}
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-2">{selectedUserForDetail.fullName}</h3>
              <p className="text-xs text-slate-500">@{selectedUserForDetail.username}</p>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl space-y-2 text-xs border border-slate-200">
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-slate-500">ตำแหน่ง:</span>
                <span className="font-semibold">{selectedUserForDetail.position}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-slate-500">ฝ่าย/สังกัด:</span>
                <span className="font-semibold">{selectedUserForDetail.department}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-slate-500">เบอร์โทรศัพท์:</span>
                <span className="font-semibold">{selectedUserForDetail.phone}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-slate-500">อีเมล:</span>
                <span className="font-semibold">{selectedUserForDetail.email}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">สิทธิ์ในระบบ:</span>
                <span className="font-bold text-blue-700">{selectedUserForDetail.role.toUpperCase()}</span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedUserForDetail(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold rounded-xl transition"
              >
                ปิดหน้าต่าง
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
