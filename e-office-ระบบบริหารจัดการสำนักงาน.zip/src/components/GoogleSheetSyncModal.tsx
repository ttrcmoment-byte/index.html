import React, { useState } from 'react';
import { GoogleSheetConfig } from '../types';
import { GOOGLE_APPS_SCRIPT_TEMPLATE, testSheetWebhook } from '../utils/googleSheets';
import { getSyncLogs, SyncLogItem } from '../utils/storage';
import { 
  X, 
  ExternalLink, 
  Copy, 
  Check, 
  RefreshCw, 
  Zap, 
  FileSpreadsheet, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  Clock
} from 'lucide-react';

interface GoogleSheetSyncModalProps {
  config: GoogleSheetConfig;
  onSaveConfig: (newConfig: GoogleSheetConfig) => void;
  onTriggerSync: () => Promise<void>;
  onClose: () => void;
  isSyncing: boolean;
}

export const GoogleSheetSyncModal: React.FC<GoogleSheetSyncModalProps> = ({
  config,
  onSaveConfig,
  onTriggerSync,
  onClose,
  isSyncing,
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [webhookInput, setWebhookInput] = useState(config.webhookUrl || '');
  const [autoSyncToggle, setAutoSyncToggle] = useState(config.autoSync);
  const [testResult, setTestResult] = useState<{ status: 'idle' | 'testing' | 'success' | 'error'; message: string }>({
    status: 'idle',
    message: '',
  });
  const [logs, setLogs] = useState<SyncLogItem[]>(getSyncLogs());

  const scriptCode = GOOGLE_APPS_SCRIPT_TEMPLATE(config.sheetId);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(scriptCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleCopySheetUrl = () => {
    navigator.clipboard.writeText(config.sheetUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const handleSave = () => {
    onSaveConfig({
      ...config,
      webhookUrl: webhookInput.trim(),
      autoSync: autoSyncToggle,
      syncStatus: webhookInput.trim() ? 'idle' : config.syncStatus,
    });
    setLogs(getSyncLogs());
  };

  const handleTestConnection = async () => {
    if (!webhookInput.trim()) {
      setTestResult({ status: 'error', message: 'กรุณาระบุ URL ของ Web App ก่อนทดสอบ' });
      return;
    }
    setTestResult({ status: 'testing', message: 'กำลังทดสอบเชื่อมต่อ Google Sheet...' });
    const success = await testSheetWebhook(webhookInput.trim(), config.sheetId);
    if (success) {
      setTestResult({ status: 'success', message: 'เชื่อมต่อกับ Google Sheet สำเร็จเรียบร้อย!' });
      handleSave();
    } else {
      setTestResult({ status: 'error', message: 'ไม่สามารถติดต่อ Webhook ได้ กรุณาตรวจสอบ URL หรือสิทธิ์การเข้าถึง (Anyone)' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full my-6 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150 border border-slate-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-white/10 rounded-xl">
              <FileSpreadsheet className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold">วิธีเปิดระบบบันทึกและซิงค์ข้อมูลลง Google Sheet</h2>
              <p className="text-xs text-emerald-100">เชื่อมโยง Google Sheet: {config.sheetId}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/70 hover:text-white rounded-lg hover:bg-white/10 transition"
            aria-label="ปิด"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto max-h-[75vh] space-y-6 text-slate-700">
          {/* Linked Sheet Details Card */}
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-emerald-800 bg-emerald-200/80 px-2 py-0.5 rounded-sm">
                  Google Sheet ID ที่ผูกไว้
                </span>
                <span className="text-xs text-emerald-700 font-mono font-bold break-all">
                  {config.sheetId}
                </span>
              </div>
              <p className="text-xs text-emerald-800 mt-1">
                สถานะ: {config.webhookUrl ? '🟢 เชื่อมต่อระบบอัตโนมัติพร้อมทำงาน' : '🟡 สแตนด์บาย (บันทึกฐานข้อมูลพร้อมซิงค์)'}
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopySheetUrl}
                className="px-3 py-1.5 bg-white border border-emerald-300 text-emerald-800 text-xs font-medium rounded-lg hover:bg-emerald-100/50 flex items-center space-x-1 transition"
              >
                {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedUrl ? 'คัดลอกลิงก์แล้ว' : 'คัดลอกลิงก์'}</span>
              </button>
              <a
                href={config.sheetUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium rounded-lg flex items-center space-x-1.5 transition shadow-xs"
              >
                <span>เปิดดู Sheet</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Quick Setup Instructions (ขั้นตอนวิธีเปิดระบบ) */}
          <div className="border border-slate-200 rounded-xl p-5 bg-slate-50">
            <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2 mb-3">
              <HelpCircle className="w-4 h-4 text-emerald-600" />
              <span>ขั้นตอนวิธีเปิดระบบบันทึกและซิงค์อัตโนมัติ (4 ขั้นตอนง่ายๆ)</span>
            </h3>

            <ol className="space-y-3 text-xs sm:text-sm text-slate-600 list-decimal list-inside">
              <li className="leading-relaxed">
                <span className="font-semibold text-slate-800">เปิด Google Sheet:</span> คลิกปุ่ม "เปิดดู Sheet" ด้านบน เพื่อเข้าสู่ Google Sheet ID: <code className="bg-slate-200 px-1 py-0.5 rounded font-mono text-xs">{config.sheetId}</code>
              </li>
              <li className="leading-relaxed">
                <span className="font-semibold text-slate-800">เปิด Apps Script:</span> ที่เมนูด้านบนของ Google Sheet เลือก <strong>ส่วนขยาย (Extensions)</strong> &gt; <strong>Apps Script</strong>
              </li>
              <li className="leading-relaxed">
                <span className="font-semibold text-slate-800">วางโค้ด Apps Script:</span> ลบโค้ดเดิมออก แล้วกดปุ่ม <strong>"คัดลอกโค้ด Apps Script"</strong> ด้านล่างนี้ไปวางในหน้าต่าง Script
              </li>
              <li className="leading-relaxed">
                <span className="font-semibold text-slate-800">ทำให้ใช้งานได้ (Deploy):</span> กด <strong>ทำให้ใช้งานได้ (Deploy)</strong> &gt; <strong>การทำให้ใช้งานได้ใหม่ (New deployment)</strong> &gt; ชนิด: <strong>เว็บแอป (Web App)</strong> &gt; ผู้มีสิทธิ์เข้าถึง: <strong>ทุกคน (Anyone)</strong> &gt; นำ URL ที่ได้มาใส่ในช่อง Webhook ด้านล่าง
              </li>
            </ol>

            {/* Code Copy Button */}
            <div className="mt-4 flex items-center justify-between bg-slate-800 text-slate-200 p-3 rounded-lg">
              <div className="text-xs font-mono truncate mr-2">
                Google Apps Script (รองรับ 5 หมวดหมู่: เอกสาร, รายรับ, รายจ่าย, สินเชื่อ, เบิกเงิน)
              </div>
              <button
                onClick={handleCopyCode}
                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold rounded flex items-center space-x-1.5 transition shrink-0"
              >
                {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCode ? 'คัดลอกโค้ดแล้ว!' : 'คัดลอกโค้ด Apps Script'}</span>
              </button>
            </div>
          </div>

          {/* Webhook Configuration Form */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
              <Zap className="w-4 h-4 text-blue-600" />
              <span>ตั้งค่าการเชื่อมต่อ (Webhook Web App URL)</span>
            </h3>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Google Apps Script Webhook URL (จากขั้นตอน Deploy)
              </label>
              <input
                type="url"
                value={webhookInput}
                onChange={(e) => setWebhookInput(e.target.value)}
                placeholder="https://script.google.com/macros/s/.../exec"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-mono focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-hidden"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                เมื่อกรอก URL นี้ ทุกครั้งที่มีการบันทึกรายการ ธุรการ/รายรับ/รายจ่าย/สินเชื่อ/เบิกเงิน ระบบจะส่งข้อมูลตรงไป Google Sheet ทันที
              </p>
            </div>

            {/* Test connection result message */}
            {testResult.message && (
              <div className={`p-3 rounded-lg text-xs flex items-center space-x-2 ${
                testResult.status === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                testResult.status === 'error' ? 'bg-red-50 text-red-800 border border-red-200' :
                'bg-blue-50 text-blue-800 border border-blue-200'
              }`}>
                {testResult.status === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
                {testResult.status === 'error' && <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />}
                {testResult.status === 'testing' && <RefreshCw className="w-4 h-4 text-blue-600 animate-spin shrink-0" />}
                <span>{testResult.message}</span>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <label className="flex items-center space-x-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={autoSyncToggle}
                  onChange={(e) => setAutoSyncToggle(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                />
                <span className="text-sm font-medium text-slate-800">
                  เปิดใช้งานการบันทึกและซิงค์ข้อมูลอัตโนมัติ (Auto-Sync)
                </span>
              </label>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={handleTestConnection}
                  disabled={testResult.status === 'testing'}
                  className="px-3 py-1.5 border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg transition"
                >
                  ทดสอบการเชื่อมต่อ
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg transition shadow-xs"
                >
                  บันทึกการตั้งค่า
                </button>
              </div>
            </div>
          </div>

          {/* Sync Trigger Action */}
          <div className="p-4 bg-slate-100 rounded-xl flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-slate-800">ซิงค์ข้อมูลทั้งหมดเดี๋ยวนี้</h4>
              <p className="text-xs text-slate-500">
                อัปเดตข้อมูลทุกรายการใน E-OFFICE เข้าสู่ Google Sheet
              </p>
            </div>
            <button
              onClick={onTriggerSync}
              disabled={isSyncing}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center space-x-2 transition shadow-sm"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'กำลังซิงค์...' : 'ซิงค์ข้อมูลทันที'}</span>
            </button>
          </div>

          {/* Sync Log History */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 flex items-center space-x-1.5">
              <Clock className="w-3.5 h-3.5" />
              <span>ประวัติการซิงค์ล่าสุด ({logs.length})</span>
            </h4>
            <div className="max-h-36 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-200 text-xs bg-white">
              {logs.length === 0 ? (
                <div className="p-4 text-center text-slate-400">ยังไม่มีประวัติการซิงค์</div>
              ) : (
                logs.slice(0, 10).map((l) => (
                  <div key={l.id} className="p-2.5 flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {l.status === 'success' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                      )}
                      <div>
                        <span className="font-medium text-slate-800">{l.action}</span>
                        <p className="text-[11px] text-slate-500">{l.details}</p>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400 shrink-0">
                      {new Date(l.timestamp).toLocaleTimeString('th-TH')}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm font-semibold rounded-xl transition"
          >
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    </div>
  );
};
