import { AppUser, GeneralRecord, GoogleSheetConfig } from './types';

export const DEFAULT_SHEET_ID = '1n2n7pq9E0pFyyVRgO_vkbobyxfu2h7CD9xPMRrqamZw';
export const DEFAULT_SHEET_URL = `https://docs.google.com/spreadsheets/d/${DEFAULT_SHEET_ID}/edit`;

export const INITIAL_USERS: AppUser[] = [
  {
    id: 'user-admin-01',
    username: 'admin',
    password: '6803024',
    fullName: 'ผู้ดูแลระบบ (Admin E-Office)',
    role: 'admin',
    department: 'สำนักบริหารกลางและเทคโนโลยีสารสนเทศ',
    position: 'ผู้อำนวยการส่วนเทคโนโลยี',
    phone: '081-999-8877',
    email: 'admin@e-office.local',
    createdAt: '2025-01-10T08:30:00Z',
    status: 'active',
  },
  {
    id: 'user-staff-01',
    username: 'somchai',
    password: 'password123',
    fullName: 'สมชาย ใจมั่นคง',
    role: 'user',
    department: 'ฝ่ายธุรการและสารบรรณ',
    position: 'เจ้าพนักงานธุรการชำนาญงาน',
    phone: '089-123-4567',
    email: 'somchai.j@e-office.local',
    createdAt: '2025-01-15T09:00:00Z',
    status: 'active',
  },
  {
    id: 'user-staff-02',
    username: 'wannipa',
    password: 'password123',
    fullName: 'วรรณิภา สุขสมบูรณ์',
    role: 'user',
    department: 'ฝ่ายการเงินและพัสดุ',
    position: 'นักวิชาการเงินและบัญชีปฏิบัติการ',
    phone: '086-555-4321',
    email: 'wannipa.s@e-office.local',
    createdAt: '2025-02-01T10:15:00Z',
    status: 'active',
  }
];

export const INITIAL_RECORDS: GeneralRecord[] = [
  // 1. Documents
  {
    id: 'rec-doc-01',
    recordNumber: 'DOC-2568-001',
    type: 'document',
    title: 'คำสั่งแต่งตั้งคณะกรรมการตรวจรับพัสดุประจำปีงบประมาณ 2568',
    description: 'คำสั่งแต่งตั้งคณะกรรมการและเจ้าหน้าที่รับผิดชอบงานจัดซื้อจัดจ้าง',
    category: 'คำสั่งภายใน',
    date: '2025-03-01',
    status: 'completed',
    documentNumber: 'ศธ 04123/ว 114',
    documentType: 'คำสั่ง',
    sender: 'สำนักงานศึกษาธิการจังหวัด',
    receiver: 'กลุ่มงานบริหารทั่วไป',
    attachments: [
      {
        id: 'att-01',
        name: 'คำสั่ง_ว114_2568.pdf',
        size: 345000,
        type: 'application/pdf',
        uploadedAt: '2025-03-01T09:20:00Z'
      }
    ],
    createdByUserId: 'user-admin-01',
    createdByName: 'ผู้ดูแลระบบ (Admin E-Office)',
    createdAt: '2025-03-01T09:20:00Z',
    updatedAt: '2025-03-01T09:20:00Z',
    syncedToGoogleSheet: true,
    syncedAt: '2025-03-01T09:25:00Z'
  },
  {
    id: 'rec-doc-02',
    recordNumber: 'DOC-2568-002',
    type: 'document',
    title: 'หนังสือแจ้งกำหนดการประชุมสัมมนาการพัฒนาระบบราชการดิจิทัล',
    description: 'เชิญบุคลากรเข้าร่วมประชุมเชิงปฏิบัติการ ณ ห้องประชุมศาลากลาง',
    category: 'หนังสือเข้า',
    date: '2025-03-05',
    status: 'completed',
    documentNumber: 'มท 0201/2568-99',
    documentType: 'หนังสือเข้า',
    sender: 'สำนักงานจังหวัด',
    receiver: 'หัวหน้าฝ่ายธุรการ',
    attachments: [
      {
        id: 'att-02',
        name: 'หนังสือเชิญประชุม_0201.pdf',
        size: 184000,
        type: 'application/pdf',
        uploadedAt: '2025-03-05T11:00:00Z'
      }
    ],
    createdByUserId: 'user-staff-01',
    createdByName: 'สมชาย ใจมั่นคง',
    createdAt: '2025-03-05T11:00:00Z',
    updatedAt: '2025-03-05T11:00:00Z',
    syncedToGoogleSheet: true,
    syncedAt: '2025-03-05T11:05:00Z'
  },

  // 2. Income
  {
    id: 'rec-inc-01',
    recordNumber: 'REV-2568-001',
    type: 'income',
    title: 'เงินโอนจัดสรรงบประมาณโครงการพัฒนาทักษะดิจิทัล',
    description: 'งบประมาณสนับสนุนจากกรมพัฒนาบุคลากรภาครัฐ งวดที่ 1',
    amount: 150000,
    category: 'งบประมาณสนับสนุน',
    date: '2025-03-02',
    status: 'completed',
    paymentMethod: 'โอนผ่านธนาคาร',
    referenceNumber: 'TRF-KTB-984210',
    attachments: [
      {
        id: 'att-03',
        name: 'สลิปโอนเงินงบประมาณ_งวด1.jpg',
        size: 125000,
        type: 'image/jpeg',
        uploadedAt: '2025-03-02T14:30:00Z'
      }
    ],
    createdByUserId: 'user-admin-01',
    createdByName: 'ผู้ดูแลระบบ (Admin E-Office)',
    createdAt: '2025-03-02T14:30:00Z',
    updatedAt: '2025-03-02T14:30:00Z',
    syncedToGoogleSheet: true,
    syncedAt: '2025-03-02T14:35:00Z'
  },
  {
    id: 'rec-inc-02',
    recordNumber: 'REV-2568-002',
    type: 'income',
    title: 'ค่าธรรมเนียมบริการจัดพิมพ์เอกสารและรับรองสำเนา',
    description: 'รายรับค่าธรรมเนียมบริการประชาชน ประจำสัปดาห์ที่ 1 มีนาคม',
    amount: 8750,
    category: 'ค่าธรรมเนียมบริการ',
    date: '2025-03-07',
    status: 'completed',
    paymentMethod: 'เงินสด',
    referenceNumber: 'RC-2568-0034',
    attachments: [],
    createdByUserId: 'user-staff-02',
    createdByName: 'วรรณิภา สุขสมบูรณ์',
    createdAt: '2025-03-07T16:00:00Z',
    updatedAt: '2025-03-07T16:00:00Z',
    syncedToGoogleSheet: true,
    syncedAt: '2025-03-07T16:05:00Z'
  },

  // 3. Expense
  {
    id: 'rec-exp-01',
    recordNumber: 'EXP-2568-001',
    type: 'expense',
    title: 'ค่ากระดาษ A4 และวัสดุสำนักงานประจำเดือนมีนาคม',
    description: 'จัดซื้อกระดาษ Double A 80 แกรม จำนวน 20 รีม และหมึกพิมพ์เลเซอร์',
    amount: 14600,
    category: 'วัสดุสำนักงาน',
    date: '2025-03-04',
    status: 'completed',
    paymentMethod: 'โอนผ่านธนาคาร',
    referenceNumber: 'INV-OFFICE-8812',
    attachments: [
      {
        id: 'att-04',
        name: 'ใบเสร็จ_ค่าวัสดุสำนักงาน.pdf',
        size: 210000,
        type: 'application/pdf',
        uploadedAt: '2025-03-04T13:10:00Z'
      }
    ],
    createdByUserId: 'user-staff-02',
    createdByName: 'วรรณิภา สุขสมบูรณ์',
    createdAt: '2025-03-04T13:10:00Z',
    updatedAt: '2025-03-04T13:10:00Z',
    syncedToGoogleSheet: true,
    syncedAt: '2025-03-04T13:15:00Z'
  },
  {
    id: 'rec-exp-02',
    recordNumber: 'EXP-2568-002',
    type: 'expense',
    title: 'ค่าบริการอินเทอร์เน็ตความเร็วสูงและระบบคลาวด์',
    description: 'ค่าบริการเครือข่ายความเร็วสูงประจำเดือน กุมภาพันธ์-มีนาคม',
    amount: 6900,
    category: 'สาธารณูปโภค',
    date: '2025-03-08',
    status: 'completed',
    paymentMethod: 'โอนผ่านธนาคาร',
    referenceNumber: 'TOT-NET-3091',
    attachments: [],
    createdByUserId: 'user-admin-01',
    createdByName: 'ผู้ดูแลระบบ (Admin E-Office)',
    createdAt: '2025-03-08T10:00:00Z',
    updatedAt: '2025-03-08T10:00:00Z',
    syncedToGoogleSheet: true,
    syncedAt: '2025-03-08T10:05:00Z'
  },

  // 4. Loan / Credit (สินเชื่อ)
  {
    id: 'rec-loan-01',
    recordNumber: 'LOAN-2568-001',
    type: 'loan',
    title: 'สัญญาเงินกู้สวัสดิการบุคลากรเพื่อการศึกษา',
    description: 'เงินกู้สวัสดิการดอกเบี้ยพิเศษสำหรับการศึกษาต่อระดับปริญญาโท',
    amount: 60000,
    category: 'สินเชื่อสวัสดิการ',
    date: '2025-02-15',
    status: 'pending',
    borrowerName: 'สมชาย ใจมั่นคง',
    installmentCount: 12,
    interestRate: 2.5,
    loanTermMonths: 12,
    dueDate: '2025-03-25',
    monthlyInstallment: 5125,
    totalPaid: 10250,
    attachments: [
      {
        id: 'att-05',
        name: 'สัญญากู้ยืมเงิน_สมชาย.pdf',
        size: 420000,
        type: 'application/pdf',
        uploadedAt: '2025-02-15T11:00:00Z'
      }
    ],
    createdByUserId: 'user-staff-01',
    createdByName: 'สมชาย ใจมั่นคง',
    createdAt: '2025-02-15T11:00:00Z',
    updatedAt: '2025-03-01T10:00:00Z',
    syncedToGoogleSheet: true,
    syncedAt: '2025-03-01T10:05:00Z'
  },
  {
    id: 'rec-loan-02',
    recordNumber: 'LOAN-2568-002',
    type: 'loan',
    title: 'เงินกู้ยืมฉุกเฉินสวัสดิการซ่อมแซมที่อยู่อาศัย',
    description: 'สินเชื่อฉุกเฉินกรณีประสบภัยน้ำท่วมซ่อมแซมบ้านพัก',
    amount: 35000,
    category: 'สินเชื่อฉุกเฉิน',
    date: '2025-01-20',
    status: 'completed',
    borrowerName: 'นายประสิทธิ์ มั่นหมาย',
    installmentCount: 6,
    interestRate: 1.5,
    loanTermMonths: 6,
    dueDate: '2025-03-20',
    monthlyInstallment: 5880,
    totalPaid: 35000,
    attachments: [],
    createdByUserId: 'user-admin-01',
    createdByName: 'ผู้ดูแลระบบ (Admin E-Office)',
    createdAt: '2025-01-20T10:00:00Z',
    updatedAt: '2025-03-05T15:00:00Z',
    syncedToGoogleSheet: true,
    syncedAt: '2025-03-05T15:05:00Z'
  },

  // 5. Withdrawal (เบิกเงิน)
  {
    id: 'rec-wth-01',
    recordNumber: 'WTH-2568-001',
    type: 'withdrawal',
    title: 'ขอเบิกเงินค่าเบี้ยเลี้ยงและค่ายานพาหนะเดินทางไปราชการ',
    description: 'เดินทางเข้าร่วมประชุมชี้แจงแนวทางการจัดทำงบประมาณ ณ กรมบัญชีกลาง',
    amount: 4500,
    category: 'เบิกค่าเดินทางไปราชการ',
    date: '2025-03-06',
    status: 'approved',
    applicantName: 'สมชาย ใจมั่นคง',
    approverName: 'ผู้ดูแลระบบ (Admin E-Office)',
    approvalDate: '2025-03-07',
    approvalNote: 'อนุมัติเรียบร้อยตามระเบียบค่าใช้จ่ายในการเดินทาง',
    attachments: [
      {
        id: 'att-06',
        name: 'ใบขออนุมัติเดินทางไปราชการ.pdf',
        size: 280000,
        type: 'application/pdf',
        uploadedAt: '2025-03-06T15:40:00Z'
      }
    ],
    createdByUserId: 'user-staff-01',
    createdByName: 'สมชาย ใจมั่นคง',
    createdAt: '2025-03-06T15:40:00Z',
    updatedAt: '2025-03-07T09:10:00Z',
    syncedToGoogleSheet: true,
    syncedAt: '2025-03-07T09:15:00Z'
  },
  {
    id: 'rec-wth-02',
    recordNumber: 'WTH-2568-002',
    type: 'withdrawal',
    title: 'ขอเบิกเงินรองจ่ายค่าซ่อมบำรุงระบบปรับอากาศห้องคอมพิวเตอร์',
    description: 'เปลี่ยนคอมเพรสเซอร์แอร์ห้อง Server เพื่อป้องกันความร้อนสะสม',
    amount: 8900,
    category: 'ค่าซ่อมบำรุงและบริการ',
    date: '2025-03-09',
    status: 'pending',
    applicantName: 'วรรณิภา สุขสมบูรณ์',
    attachments: [],
    createdByUserId: 'user-staff-02',
    createdByName: 'วรรณิภา สุขสมบูรณ์',
    createdAt: '2025-03-09T11:20:00Z',
    updatedAt: '2025-03-09T11:20:00Z',
    syncedToGoogleSheet: false
  }
];

export const INITIAL_SHEET_CONFIG: GoogleSheetConfig = {
  sheetId: DEFAULT_SHEET_ID,
  sheetUrl: DEFAULT_SHEET_URL,
  webhookUrl: '',
  autoSync: true,
  lastSyncedAt: '2025-03-09T10:00:00Z',
  syncStatus: 'idle',
  totalSyncedCount: 7
};
